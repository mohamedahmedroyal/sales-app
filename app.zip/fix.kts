subprojects {
    try {
        afterEvaluate {
            val ext = extensions.findByName("android")
            if (ext != null) {
                try {
                    val m = ext.javaClass.getMethod("setCompileSdk", Int::class.javaObjectType)
                    m.isAccessible = true
                    m.invoke(ext, 36)
                } catch (e: Exception) {
                    println("compileSdk override skipped for ${project.name}: $e")
                }
            }
        }
    } catch (e: Exception) {
        println("compileSdk hook skipped: $e")
    }
}

