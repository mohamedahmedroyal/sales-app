# runs from the repo root after "flutter create": forces compileSdk 36 on all plugins
if [ -f app/android/build.gradle.kts ]; then
  cat src/fix.kts app/android/build.gradle.kts > /tmp/b.kts && mv /tmp/b.kts app/android/build.gradle.kts
  echo "patched build.gradle.kts"
elif [ -f app/android/build.gradle ]; then
  cat src/fix.gradle app/android/build.gradle > /tmp/b.gradle && mv /tmp/b.gradle app/android/build.gradle
  echo "patched build.gradle"
else
  echo "no root gradle file found"
fi
