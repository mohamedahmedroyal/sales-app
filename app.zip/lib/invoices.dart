import 'package:flutter/material.dart';
import 'core.dart';
import 'products.dart';
import 'parties.dart';

class InvoicePage extends StatefulWidget {
  final String type; // sale | purchase | sale_return | purchase_return
  const InvoicePage(this.type, {super.key});
  @override
  State<InvoicePage> createState() => _IS();
}

class _IS extends State<InvoicePage> {
  Map<String, Object?>? party;
  final lines = <Map<String, dynamic>>[];
  final disc = TextEditingController(text: '0'), paid = TextEditingController(text: '0');
  String mode = 'cash';
  String get type => widget.type;
  bool get cust => type == 'sale' || type == 'sale_return';
  bool get ret => type.endsWith('return');
  bool get out => type == 'sale' || type == 'purchase_return'; // stock decreases
  double get sub => lines.fold(0.0, (s, l) => s + n(l['qty']) * n(l['price']));
  double get total => sub - pd(disc.text);
  double get paidAmt {
    final t = total;
    if (mode == 'cash') return t;
    if (mode == 'credit') return 0;
    final x = pd(paid.text);
    return x > t ? t : x;
  }

  void msg(String t) => ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(t)));

  Future<void> addLine() async {
    final pr = await Navigator.push<Map<String, Object?>>(context, MaterialPageRoute(builder: (_) => const ProductsPage(pick: true)));
    if (pr == null || !mounted) return;
    final q = TextEditingController(text: '1');
    final pc = TextEditingController(text: f(n(cust ? pr['price'] : pr['cost'])));
    final ok = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        title: Text(pr['name'] as String),
        content: Column(mainAxisSize: MainAxisSize.min, children: [tf(q, 'الكمية', isNum: true), tf(pc, 'السعر', isNum: true)]),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('إلغاء')),
          FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('إضافة')),
        ],
      ),
    );
    if (ok != true || pd(q.text) <= 0) return;
    final already = lines.where((l) => l['product_id'] == pr['id']).fold<double>(0, (s, l) => s + n(l['qty']));
    if (out && pd(q.text) + already > n(pr['qty'])) {
      msg('الكمية أكبر من المتاح (${f(n(pr['qty']))})');
      return;
    }
    setState(() => lines.add({'product_id': pr['id'], 'name': pr['name'], 'qty': pd(q.text), 'price': pd(pc.text)}));
  }

  Future<void> pickParty() async {
    final r = await Navigator.push<Map<String, Object?>>(context, MaterialPageRoute(builder: (_) => PartiesPage(cust ? 'customer' : 'supplier', pick: true)));
    if (r != null) setState(() => party = r);
  }

  Future<void> save() async {
    if (lines.isEmpty) return msg('أضف صنف واحد على الأقل');
    final t = total, pa = paidAmt;
    if (pa < t && party == null) return msg(cust ? 'اختر العميل' : 'اختر المورد');
    if (type == 'sale' && party != null && pa < t) {
      final lim = n(party!['credit_limit']);
      final r = await DB.q('SELECT ${DB.bal} b FROM parties p WHERE p.id=?', [party!['id']]);
      if (lim > 0 && n(r[0]['b']) + t - pa > lim) {
        if (!mounted) return;
        final go = await showDialog<bool>(
          context: context,
          builder: (_) => AlertDialog(
            title: const Text('تجاوز الحد الائتماني'),
            content: const Text('هذه الفاتورة ستتجاوز الحد الائتماني للعميل. هل تريد المتابعة؟'),
            actions: [
              TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('لا')),
              FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('متابعة')),
            ],
          ),
        );
        if (go != true) return;
      }
    }
    await DB.saveInvoice(type, party?['id'] as int?, lines, pd(disc.text), pa);
    if (mounted) Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: Text(titles[type]!)),
        body: ListView(padding: const EdgeInsets.all(12), children: [
          Card(
            child: ListTile(
              leading: const Icon(Icons.person),
              title: Text(party == null ? (cust ? 'عميل نقدي (اختياري)' : 'اختر المورد (اختياري للنقدي)') : party!['name'] as String),
              trailing: const Icon(Icons.chevron_left),
              onTap: pickParty,
            ),
          ),
          for (var i = 0; i < lines.length; i++)
            Card(
              child: ListTile(
                title: Text(lines[i]['name'] as String),
                subtitle: Text('${f(n(lines[i]['qty']))} × ${f(n(lines[i]['price']))}'),
                trailing: Row(mainAxisSize: MainAxisSize.min, children: [
                  Text(f(n(lines[i]['qty']) * n(lines[i]['price'])), style: const TextStyle(fontWeight: FontWeight.bold)),
                  IconButton(icon: const Icon(Icons.delete_outline), onPressed: () => setState(() => lines.removeAt(i))),
                ]),
              ),
            ),
          OutlinedButton.icon(onPressed: addLine, icon: const Icon(Icons.add), label: const Text('إضافة صنف')),
          const SizedBox(height: 8),
          tf(disc, 'الخصم', isNum: true, onChanged: (_) => setState(() {})),
          SegmentedButton<String>(
            segments: [
              ButtonSegment(value: 'cash', label: Text(ret ? 'استرداد نقدي' : 'كاش')),
              ButtonSegment(value: 'credit', label: Text(ret ? 'خصم من الحساب' : 'آجل')),
              if (!ret) const ButtonSegment(value: 'partial', label: Text('جزئي')),
            ],
            selected: {mode},
            onSelectionChanged: (s) => setState(() => mode = s.first),
          ),
          if (mode == 'partial') tf(paid, 'المدفوع', isNum: true, onChanged: (_) => setState(() {})),
          Card(
            child: Padding(
              padding: const EdgeInsets.all(12),
              child: Column(children: [
                Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [const Text('الإجمالي'), Text(f(total), style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold))]),
                Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [Text(ret ? 'المسترد نقدًا' : 'المدفوع'), Text(f(paidAmt))]),
                Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [Text(ret ? 'يخصم من الحساب' : 'المتبقي (آجل)'), Text(f(total - paidAmt))]),
              ]),
            ),
          ),
          FilledButton(onPressed: save, child: const Padding(padding: EdgeInsets.all(8), child: Text('حفظ'))),
        ]),
      );
}

class InvoicesPage extends StatelessWidget {
  const InvoicesPage({super.key});

  Widget list(BuildContext context, List<String> types) => FutureBuilder<List<Map<String, Object?>>>(
        future: DB.q(
          'SELECT i.*, p.name pname FROM invoices i LEFT JOIN parties p ON p.id=i.party_id WHERE i.type IN (${types.map((_) => '?').join(',')}) ORDER BY i.id DESC',
          types,
        ),
        builder: (ctx, s) {
          final r = s.data ?? [];
          return ListView(padding: const EdgeInsets.all(8), children: [
            for (final m in r)
              Card(
                child: ListTile(
                  title: Text('${titles[m['type']]} #${m['id']} — ${f(n(m['total']))}'),
                  subtitle: Text('${(m['date'] as String).substring(0, 10)}  ${m['pname'] ?? 'نقدي'}  |  المتبقي: ${f(n(m['total']) - n(m['paid']))}'),
                  onTap: () async {
                    final it = await DB.q('SELECT * FROM items WHERE invoice_id=?', [m['id']]);
                    if (!ctx.mounted) return;
                    showDialog(
                      context: ctx,
                      builder: (_) => AlertDialog(
                        title: Text('${titles[m['type']]} #${m['id']}'),
                        content: Column(mainAxisSize: MainAxisSize.min, children: [
                          for (final x in it) ListTile(dense: true, title: Text(x['name'] as String), trailing: Text('${f(n(x['qty']))} × ${f(n(x['price']))}')),
                          Text('الخصم: ${f(n(m['discount']))}  |  المدفوع: ${f(n(m['paid']))}'),
                        ]),
                      ),
                    );
                  },
                ),
              ),
          ]);
        },
      );

  @override
  Widget build(BuildContext context) => DefaultTabController(
        length: 3,
        child: Scaffold(
          appBar: AppBar(title: const Text('الفواتير'), bottom: const TabBar(tabs: [Tab(text: 'مبيعات'), Tab(text: 'مشتريات'), Tab(text: 'مرتجعات')])),
          body: TabBarView(children: [
            list(context, ['sale']),
            list(context, ['purchase']),
            list(context, ['sale_return', 'purchase_return']),
          ]),
        ),
      );
}
