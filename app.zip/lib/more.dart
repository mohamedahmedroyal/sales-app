import 'package:flutter/material.dart';
import 'core.dart';
import 'parties.dart';

class CollectionsPage extends StatefulWidget {
  const CollectionsPage({super.key});
  @override
  State<CollectionsPage> createState() => _CS();
}

class _CS extends State<CollectionsPage> {
  Future<void> add(BuildContext ctx, String type) async {
    final party = await Navigator.push<Map<String, Object?>>(ctx, MaterialPageRoute(builder: (_) => PartiesPage(type, pick: true)));
    if (party == null || !ctx.mounted) return;
    if (await askPayment(ctx, party)) setState(() {});
  }

  Widget list(String type) => FutureBuilder<List<Map<String, Object?>>>(
        future: DB.q('SELECT y.*, p.name pname FROM payments y JOIN parties p ON p.id=y.party_id WHERE p.type=? ORDER BY y.id DESC', [type]),
        builder: (c, s) {
          final r = s.data ?? [];
          final total = r.fold<double>(0, (a, m) => a + n(m['amount']));
          final todayT = r.where((m) => (m['date'] as String).startsWith(today())).fold<double>(0, (a, m) => a + n(m['amount']));
          return Column(children: [
            Card(
              color: Colors.green.shade50,
              child: ListTile(
                title: Text('اليوم: ${f(todayT)}'),
                trailing: Text('الإجمالي: ${f(total)}', style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
              ),
            ),
            Expanded(
              child: ListView(padding: const EdgeInsets.symmetric(horizontal: 8), children: [
                for (final m in r)
                  Card(
                    child: ListTile(
                      leading: icon3d(Icons.payments_rounded, const Color(0xFF22C55E), size: 40),
                      title: Text(m['pname'] as String),
                      subtitle: Text('${(m['date'] as String).substring(0, 10)}  ${m['note'] ?? ''}'),
                      trailing: Text(f(n(m['amount'])), style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
                    ),
                  ),
              ]),
            ),
          ]);
        },
      );

  @override
  Widget build(BuildContext context) => DefaultTabController(
        length: 2,
        child: Builder(
          builder: (ctx) => Scaffold(
            appBar: AppBar(title: const Text('التحصيلات'), bottom: const TabBar(tabs: [Tab(text: 'تحصيلات العملاء'), Tab(text: 'مدفوعات الموردين')])),
            floatingActionButton: FloatingActionButton.extended(
              onPressed: () => add(ctx, DefaultTabController.of(ctx).index == 0 ? 'customer' : 'supplier'),
              icon: const Icon(Icons.add),
              label: const Text('تسجيل دفعة'),
            ),
            body: TabBarView(children: [list('customer'), list('supplier')]),
          ),
        ),
      );
}

class ExpensesPage extends StatefulWidget {
  const ExpensesPage({super.key});
  @override
  State<ExpensesPage> createState() => _XS();
}

class _XS extends State<ExpensesPage> {
  Future<void> add() async {
    const cats = ['إيجار', 'كهرباء ومياه', 'مرتبات', 'نقل', 'صيانة', 'أخرى'];
    var cat = cats.last;
    final a = TextEditingController(), note = TextEditingController();
    final ok = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('مصروف جديد'),
        content: SingleChildScrollView(
          child: StatefulBuilder(
            builder: (ctx, set) => Column(mainAxisSize: MainAxisSize.min, children: [
              Wrap(spacing: 6, children: [for (final k in cats) ChoiceChip(label: Text(k), selected: cat == k, onSelected: (_) => set(() => cat = k))]),
              tf(a, 'المبلغ', isNum: true),
              tf(note, 'ملاحظة'),
            ]),
          ),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('إلغاء')),
          FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('حفظ')),
        ],
      ),
    );
    if (ok != true || pd(a.text) <= 0) return;
    await DB.ins('expenses', {'category': cat, 'amount': pd(a.text), 'date': DateTime.now().toIso8601String(), 'note': note.text.trim()});
    setState(() {});
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('المصاريف')),
        floatingActionButton: FloatingActionButton.extended(onPressed: add, icon: const Icon(Icons.add), label: const Text('مصروف جديد')),
        body: FutureBuilder<List<List<Map<String, Object?>>>>(
          future: Future.wait([
            DB.q('SELECT COALESCE(SUM(amount),0) v FROM expenses WHERE date>=?', [monthStart()]),
            DB.q('SELECT * FROM expenses ORDER BY id DESC'),
          ]),
          builder: (c, s) {
            if (!s.hasData) return const SizedBox();
            final month = n(s.data![0][0]['v']);
            final r = s.data![1];
            return Column(children: [
              Card(
                color: Colors.red.shade50,
                child: ListTile(title: const Text('مصاريف هذا الشهر'), trailing: Text(f(month), style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 20))),
              ),
              Expanded(
                child: ListView(padding: const EdgeInsets.symmetric(horizontal: 8), children: [
                  for (final m in r)
                    Card(
                      child: ListTile(
                        leading: icon3d(Icons.account_balance_wallet_rounded, const Color(0xFFEF4444), size: 40),
                        title: Text(m['category'] as String),
                        subtitle: Text('${(m['date'] as String).substring(0, 10)}  ${m['note'] ?? ''}'),
                        trailing: Row(mainAxisSize: MainAxisSize.min, children: [
                          Text(f(n(m['amount'])), style: const TextStyle(fontWeight: FontWeight.bold)),
                          IconButton(
                            icon: const Icon(Icons.delete_outline),
                            onPressed: () async {
                              if (await confirm(context, 'حذف هذا المصروف؟')) {
                                await DB.del('expenses', m['id'] as int);
                                setState(() {});
                              }
                            },
                          ),
                        ]),
                      ),
                    ),
                ]),
              ),
            ]);
          },
        ),
      );
}

class ReportsPage extends StatefulWidget {
  const ReportsPage({super.key});
  @override
  State<ReportsPage> createState() => _RS();
}

class _RS extends State<ReportsPage> {
  int per = 1;

  Future<Map<String, dynamic>> load() async {
    final s = per == 0 ? today() : (per == 1 ? monthStart() : '');
    Future<double> one(String sql, [List<Object?>? a]) async => n((await DB.q(sql, a))[0]['v']);
    final sales = await one("SELECT COALESCE(SUM(total),0) v FROM invoices WHERE type='sale' AND date>=?", [s]);
    final sret = await one("SELECT COALESCE(SUM(total),0) v FROM invoices WHERE type='sale_return' AND date>=?", [s]);
    final purch = await one("SELECT COALESCE(SUM(total),0) v FROM invoices WHERE type='purchase' AND date>=?", [s]);
    final cogsS = await one("SELECT COALESCE(SUM(it.qty*it.cost),0) v FROM items it JOIN invoices i ON i.id=it.invoice_id WHERE i.type='sale' AND i.date>=?", [s]);
    final cogsR = await one("SELECT COALESCE(SUM(it.qty*it.cost),0) v FROM items it JOIN invoices i ON i.id=it.invoice_id WHERE i.type='sale_return' AND i.date>=?", [s]);
    final exp = await one('SELECT COALESCE(SUM(amount),0) v FROM expenses WHERE date>=?', [s]);
    final coll = await one("SELECT COALESCE(SUM(y.amount),0) v FROM payments y JOIN parties p ON p.id=y.party_id WHERE p.type='customer' AND y.date>=?", [s]);
    final sc = await one('SELECT COALESCE(SUM(qty*cost),0) v FROM products');
    final sr = await one('SELECT COALESCE(SUM(qty*price),0) v FROM products');
    final top = await DB.q("SELECT it.name pname, SUM(it.qty) q FROM items it JOIN invoices i ON i.id=it.invoice_id WHERE i.type='sale' AND i.date>=? GROUP BY it.name ORDER BY q DESC LIMIT 5", [s]);
    final net = sales - sret;
    final gross = net - (cogsS - cogsR);
    return {'net': net, 'purch': purch, 'gross': gross, 'exp': exp, 'profit': gross - exp, 'coll': coll, 'sc': sc, 'sr': sr, 'top': top};
  }

  Widget line(String t, double v, {bool bold = false, Color? c}) => ListTile(
        dense: true,
        title: Text(t, style: TextStyle(fontWeight: bold ? FontWeight.bold : null)),
        trailing: Text(f(v), style: TextStyle(fontWeight: FontWeight.bold, fontSize: bold ? 18 : 15, color: c)),
      );

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('التقارير')),
        body: FutureBuilder<Map<String, dynamic>>(
          future: load(),
          builder: (c, s) {
            final d = s.data;
            return ListView(padding: const EdgeInsets.all(8), children: [
              Wrap(spacing: 8, children: [
                for (final e in [(0, 'اليوم'), (1, 'هذا الشهر'), (2, 'الكل')])
                  ChoiceChip(label: Text(e.$2), selected: per == e.$1, onSelected: (_) => setState(() => per = e.$1)),
              ]),
              if (d != null) ...[
                Card(
                  child: Column(children: [
                    line('صافي المبيعات (بعد المرتجعات)', d['net'] as double),
                    line('إجمالي الربح', d['gross'] as double),
                    line('المصاريف', d['exp'] as double, c: Colors.red),
                    const Divider(),
                    line('صافي الربح', d['profit'] as double, bold: true, c: (d['profit'] as double) >= 0 ? Colors.green : Colors.red),
                  ]),
                ),
                Card(
                  child: Column(children: [
                    line('المشتريات', d['purch'] as double),
                    line('تحصيلات من العملاء (بعد البيع)', d['coll'] as double),
                    line('قيمة المخزون بسعر الشراء', d['sc'] as double),
                    line('قيمة المخزون بسعر البيع', d['sr'] as double),
                  ]),
                ),
                Card(
                  child: Column(children: [
                    const ListTile(dense: true, title: Text('أكثر الأصناف مبيعًا', style: TextStyle(fontWeight: FontWeight.bold))),
                    for (final m in d['top'] as List<Map<String, Object?>>) line(m['pname'] as String, n(m['q'])),
                    if ((d['top'] as List).isEmpty) const ListTile(dense: true, title: Text('لا توجد مبيعات')),
                  ]),
                ),
              ],
            ]);
          },
        ),
      );
}
