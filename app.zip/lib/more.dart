import 'package:flutter/material.dart';
import 'core.dart';
import 'parties.dart';
import 'pdf.dart';

class CollectionsPage extends StatefulWidget {
  const CollectionsPage({super.key});
  @override
  State<CollectionsPage> createState() => _CS();
}

class _CS extends State<CollectionsPage> {
  Future<void> add(BuildContext ctx, String type) async {
    final party = await Navigator.push<Map<String, Object?>>(ctx, MaterialPageRoute(builder: (_) => PartiesPage(type, pick: true)));
    if (party == null || !ctx.mounted) return;
    if (await askPayment(ctx, party)) setState(() {});
  }

  Widget list(String type) => FutureBuilder<List<Map<String, Object?>>>(
        future: DB.q('SELECT y.*, p.name pname FROM payments y JOIN parties p ON p.id=y.party_id WHERE p.type=? ORDER BY y.id DESC', [type]),
        builder: (c, s) {
          final r = s.data ?? [];
          final total = r.fold<double>(0, (a, m) => a + n(m['amount']));
          final todayT = r.where((m) => (m['date'] as String).startsWith(today())).fold<double>(0, (a, m) => a + n(m['amount']));
          return Column(children: [
            Card(
              color: Colors.green.shade50,
              child: ListTile(
                title: Text('اليوم: ${f(todayT)}'),
                trailing: Text('الإجمالي: ${f(total)}', style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
              ),
            ),
            Expanded(
              child: ListView(padding: const EdgeInsets.symmetric(horizontal: 8), children: [
                for (final m in r)
                  Card(
                    child: ListTile(
                      leading: icon3d(Icons.payments_rounded, const Color(0xFF22C55E), size: 40),
                      title: Text(m['pname'] as String),
                      subtitle: Text('${(m['date'] as String).substring(0, 10)}  ${m['note'] ?? ''}'),
                      trailing: Text(f(n(m['amount'])), style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
                    ),
                  ),
              ]),
            ),
          ]);
        },
      );

  @override
  Widget build(BuildContext context) => DefaultTabController(
        length: 2,
        child: Builder(
          builder: (ctx) => Scaffold(
            appBar: AppBar(title: const Text('التحصيلات'), bottom: const TabBar(tabs: [Tab(text: 'تحصيلات العملاء'), Tab(text: 'مدفوعات الموردين')])),
            floatingActionButton: FloatingActionButton.extended(
              onPressed: () => add(ctx, DefaultTabController.of(ctx).index == 0 ? 'customer' : 'supplier'),
              icon: const Icon(Icons.add),
              label: const Text('تسجيل دفعة'),
            ),
            body: TabBarView(children: [list('customer'), list('supplier')]),
          ),
        ),
      );
}

class ExpensesPage extends StatefulWidget {
  const ExpensesPage({super.key});
  @override
  State<ExpensesPage> createState() => _XS();
}

class _XS extends State<ExpensesPage> {
  Future<void> add() async {
    const cats = ['إيجار', 'كهرباء ومياه', 'مرتبات', 'نقل', 'صيانة', 'أخرى'];
    var cat = cats.last;
    var dt = DateTime.now();
    final a = TextEditingController(), note = TextEditingController();
    final ok = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('مصروف جديد'),
        content: SingleChildScrollView(
          child: StatefulBuilder(
            builder: (ctx, set) => Column(mainAxisSize: MainAxisSize.min, children: [
              Wrap(spacing: 6, children: [for (final k in cats) ChoiceChip(label: Text(k), selected: cat == k, onSelected: (_) => set(() => cat = k))]),
              tf(a, 'المبلغ', isNum: true),
              tf(note, 'ملاحظة'),
              dateTile(ctx, dt, (d) => set(() => dt = d)),
            ]),
          ),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('إلغاء')),
          FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('حفظ')),
        ],
      ),
    );
    if (ok != true || pd(a.text) <= 0) return;
    await DB.ins('expenses', {'category': cat, 'amount': pd(a.text), 'date': dt.toIso8601String(), 'note': note.text.trim()});
    setState(() {});
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('المصاريف')),
        floatingActionButton: FloatingActionButton.extended(onPressed: add, icon: const Icon(Icons.add), label: const Text('مصروف جديد')),
        body: FutureBuilder<List<List<Map<String, Object?>>>>(
          future: Future.wait([
            DB.q('SELECT COALESCE(SUM(amount),0) v FROM expenses WHERE date>=?', [monthStart()]),
            DB.q('SELECT * FROM expenses ORDER BY id DESC'),
          ]),
          builder: (c, s) {
            if (!s.hasData) return const SizedBox();
            final month = n(s.data![0][0]['v']);
            final r = s.data![1];
            return Column(children: [
              Card(
                color: Colors.red.shade50,
                child: ListTile(title: const Text('مصاريف هذا الشهر'), trailing: Text(f(month), style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 20))),
              ),
              Expanded(
                child: ListView(padding: const EdgeInsets.symmetric(horizontal: 8), children: [
                  for (final m in r)
                    Card(
                      child: ListTile(
                        leading: icon3d(Icons.account_balance_wallet_rounded, const Color(0xFFEF4444), size: 40),
                        title: Text(m['category'] as String),
                        subtitle: Text('${(m['date'] as String).substring(0, 10)}  ${m['note'] ?? ''}'),
                        trailing: Row(mainAxisSize: MainAxisSize.min, children: [
                          Text(f(n(m['amount'])), style: const TextStyle(fontWeight: FontWeight.bold)),
                          IconButton(
                            icon: const Icon(Icons.delete_outline),
                            onPressed: () async {
                              if (await confirm(context, 'حذف هذا المصروف؟')) {
                                await DB.del('expenses', m['id'] as int);
                                setState(() {});
                              }
                            },
                          ),
                        ]),
                      ),
                    ),
                ]),
              ),
            ]);
          },
        ),
      );
}

class ReportsPage extends StatefulWidget {
  const ReportsPage({super.key});
  @override
  State<ReportsPage> createState() => _RS();
}

class _RS extends State<ReportsPage> {
  int per = 1;
  DateTimeRange? range;
  List<List<String>> _rows = [];

  Future<Map<String, dynamic>> load() async {
    final b = bounds(per, range);
    Future<double> one(String sql, [List<Object?>? a]) async => n((await DB.q(sql, a))[0]['v']);
    Future<double> inv(String t) => one('SELECT COALESCE(SUM(total),0) v FROM invoices WHERE type=? AND date>=? AND date<?', [t, b[0], b[1]]);
    Future<double> cg(String t) => one('SELECT COALESCE(SUM(it.qty*it.cost),0) v FROM items it JOIN invoices i ON i.id=it.invoice_id WHERE i.type=? AND i.date>=? AND i.date<?', [t, b[0], b[1]]);
    final sales = await inv('sale'), sret = await inv('sale_return'), purch = await inv('purchase'), pret = await inv('purchase_return');
    final cogs = await cg('sale') - await cg('sale_return');
    final exp = await one('SELECT COALESCE(SUM(amount),0) v FROM expenses WHERE date>=? AND date<?', [b[0], b[1]]);
    final coll = await one("SELECT COALESCE(SUM(y.amount),0) v FROM payments y JOIN parties p ON p.id=y.party_id WHERE p.type='customer' AND y.date>=? AND y.date<?", [b[0], b[1]]);
    final cnt = await one("SELECT COUNT(*) v FROM invoices WHERE type='sale' AND date>=? AND date<?", [b[0], b[1]]);
    final sc = await one('SELECT COALESCE(SUM(qty*cost),0) v FROM products');
    final sr = await one('SELECT COALESCE(SUM(qty*price),0) v FROM products');
    final top = await DB.q("SELECT it.name pname, SUM(it.qty) q FROM items it JOIN invoices i ON i.id=it.invoice_id WHERE i.type='sale' AND i.date>=? AND i.date<? GROUP BY it.name ORDER BY q DESC LIMIT 5", [b[0], b[1]]);
    final net = sales - sret, gross = net - cogs;
    return {'net': net, 'purch': purch - pret, 'gross': gross, 'exp': exp, 'profit': gross - exp, 'coll': coll, 'cnt': cnt, 'sc': sc, 'sr': sr, 'top': top};
  }

  Widget line(String t, double v, {bool bold = false, Color? c}) => ListTile(
        dense: true,
        title: Text(t, style: TextStyle(fontWeight: bold ? FontWeight.bold : null)),
        trailing: Text(f(v), style: TextStyle(fontWeight: FontWeight.bold, fontSize: bold ? 18 : 15, color: c)),
      );

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('التقارير'), actions: [
          IconButton(tooltip: 'تقرير PDF', icon: const Icon(Icons.picture_as_pdf_rounded), onPressed: () => sharePdf(context, 'report_${today()}', htmlDoc('تقرير المبيعات والأرباح', periodLabel(per, range), ['البند', 'القيمة'], _rows))),
          IconButton(tooltip: 'كشف المخزون PDF', icon: const Icon(Icons.inventory_2_rounded), onPressed: () => stockPdf(context)),
        ]),
        body: FutureBuilder<Map<String, dynamic>>(
          future: load(),
          builder: (c, s) {
            final d = s.data;
            if (d != null) {
              _rows = [
                ['عدد فواتير البيع', f(d['cnt'] as double)],
                ['صافي المبيعات (بعد المرتجعات)', f(d['net'] as double)],
                ['إجمالي الربح', f(d['gross'] as double)],
                ['المصاريف', f(d['exp'] as double)],
                ['صافي الربح', f(d['profit'] as double)],
                ['المشتريات (بعد المرتجعات)', f(d['purch'] as double)],
                ['تحصيلات من العملاء', f(d['coll'] as double)],
                ['قيمة المخزون بسعر الشراء', f(d['sc'] as double)],
                ['قيمة المخزون بسعر البيع', f(d['sr'] as double)],
                for (final m in d['top'] as List<Map<String, Object?>>) ['من الأكثر مبيعًا: ${m['pname']}', f(n(m['q']))],
              ];
            }
            return ListView(padding: const EdgeInsets.all(8), children: [
              periodChips(context, per, range, (p, r) => setState(() {
                    per = p;
                    range = r;
                  })),
              if (d != null) ...[
                Card(
                  child: Column(children: [
                    line('عدد فواتير البيع', d['cnt'] as double),
                    line('صافي المبيعات (بعد المرتجعات)', d['net'] as double),
                    line('إجمالي الربح', d['gross'] as double),
                    line('المصاريف', d['exp'] as double, c: Colors.red),
                    const Divider(),
                    line('صافي الربح', d['profit'] as double, bold: true, c: (d['profit'] as double) >= 0 ? Colors.green : Colors.red),
                  ]),
                ),
                Card(
                  child: Column(children: [
                    line('المشتريات (بعد المرتجعات)', d['purch'] as double),
                    line('تحصيلات من العملاء', d['coll'] as double),
                    line('قيمة المخزون بسعر الشراء', d['sc'] as double),
                    line('قيمة المخزون بسعر البيع', d['sr'] as double),
                  ]),
                ),
                Card(
                  child: Column(children: [
                    const ListTile(dense: true, title: Text('أكثر الأصناف مبيعًا', style: TextStyle(fontWeight: FontWeight.bold))),
                    for (final m in d['top'] as List<Map<String, Object?>>) line(m['pname'] as String, n(m['q'])),
                    if ((d['top'] as List).isEmpty) const ListTile(dense: true, title: Text('لا توجد مبيعات')),
                  ]),
                ),
              ],
            ]);
          },
        ),
      );
}

class CompanyPage extends StatefulWidget {
  const CompanyPage({super.key});
  @override
  State<CompanyPage> createState() => _CP();
}

class _CP extends State<CompanyPage> {
  int per = 1;
  DateTimeRange? range;
  List<List<String>> _rows = [];

  Future<Map<String, double>> cash(String lo, String hi) async {
    final p = [lo, hi];
    Future<double> one(String sql) async => n((await DB.q(sql, p))[0]['v']);
    Future<double> pd2(String t) => one("SELECT COALESCE(SUM(paid),0) v FROM invoices WHERE type='$t' AND date>=? AND date<?");
    Future<double> py(String t) => one("SELECT COALESCE(SUM(y.amount),0) v FROM payments y JOIN parties p ON p.id=y.party_id WHERE p.type='$t' AND y.date>=? AND y.date<?");
    final cs = await pd2('sale'), cr = await pd2('sale_return'), pp = await pd2('purchase'), pr = await pd2('purchase_return');
    final col = await py('customer'), sp = await py('supplier');
    final ex = await one('SELECT COALESCE(SUM(amount),0) v FROM expenses WHERE date>=? AND date<?');
    final tr = await one('SELECT COALESCE(SUM(amount),0) v FROM transfers WHERE date>=? AND date<?');
    return {'cs': cs, 'col': col, 'pr': pr, 'cr': cr, 'pp': pp, 'sp': sp, 'ex': ex, 'tr': tr, 'net': cs + col + pr - cr - pp - sp - ex - tr};
  }

  Future<void> editTransfer([Map<String, Object?>? m]) async {
    final a = TextEditingController(text: m == null ? '' : f(n(m['amount']))), note = TextEditingController(text: (m?['note'] ?? '').toString());
    var dt = m == null ? DateTime.now() : (DateTime.tryParse(m['date'] as String) ?? DateTime.now());
    final r = await showDialog<String>(
      context: context,
      builder: (_) => AlertDialog(
        title: Text(m == null ? 'تحويل للشركة' : 'تعديل التحويل'),
        content: StatefulBuilder(builder: (ctx, set) => Column(mainAxisSize: MainAxisSize.min, children: [tf(a, 'المبلغ المحوّل', isNum: true), tf(note, 'ملاحظة (رقم العملية / طريقة التحويل)'), dateTile(ctx, dt, (d) => set(() => dt = d))])),
        actions: [
          if (m != null) TextButton(onPressed: () => Navigator.pop(context, 'del'), child: const Text('حذف', style: TextStyle(color: Colors.red))),
          TextButton(onPressed: () => Navigator.pop(context, 'no'), child: const Text('إلغاء')),
          FilledButton(onPressed: () => Navigator.pop(context, 'ok'), child: const Text('حفظ')),
        ],
      ),
    );
    if (r == 'ok' && pd(a.text) > 0) {
      final v = <String, Object?>{'amount': pd(a.text), 'note': note.text.trim(), 'date': dt.toIso8601String()};
      if (m == null) {
        await DB.ins('transfers', v);
      } else {
        await DB.upd('transfers', v, m['id'] as int);
      }
    } else if (r == 'del' && mounted && await confirm(context, 'حذف هذا التحويل؟')) {
      await DB.del('transfers', m!['id'] as int);
    }
    if (mounted) setState(() {});
  }

  Widget line(String t, double v, {bool bold = false, Color? c}) => ListTile(
        dense: true,
        title: Text(t, style: TextStyle(fontWeight: bold ? FontWeight.bold : null)),
        trailing: Text(f(v), style: TextStyle(fontWeight: FontWeight.bold, fontSize: bold ? 18 : 15, color: c)),
      );

  @override
  Widget build(BuildContext context) {
    final b = bounds(per, range);
    return Scaffold(
      appBar: AppBar(title: const Text('حسابي مع الشركة'), actions: [
        IconButton(tooltip: 'PDF', icon: const Icon(Icons.picture_as_pdf_rounded), onPressed: () => sharePdf(context, 'company_${today()}', htmlDoc('حساب المندوب مع الشركة', periodLabel(per, range), ['البند', 'القيمة'], _rows))),
      ]),
      floatingActionButton: FloatingActionButton.extended(onPressed: () => editTransfer(), icon: const Icon(Icons.send_rounded), label: const Text('تحويل للشركة')),
      body: FutureBuilder<List<Object>>(
        future: Future.wait<Object>([cash(b[0], b[1]), cash('', '9999'), DB.q('SELECT * FROM transfers WHERE date>=? AND date<? ORDER BY date DESC', [b[0], b[1]])]),
        builder: (c, s) {
          if (!s.hasData) return const SizedBox();
          final d = s.data![0] as Map<String, double>, all = s.data![1] as Map<String, double>;
          final tr = s.data![2] as List<Map<String, Object?>>;
          _rows = [
            ['مبيعات نقدية', f(d['cs']!)],
            ['تحصيلات من العملاء', f(d['col']!)],
            ['مرتجع شراء مستلم', f(d['pr']!)],
            ['مرتجع بيع مسترد', f(d['cr']!)],
            ['مشتريات مدفوعة', f(d['pp']!)],
            ['مدفوعات للموردين', f(d['sp']!)],
            ['المصروفات', f(d['ex']!)],
            ['التحويلات للشركة', f(d['tr']!)],
            ['صافي الفترة', f(d['net']!)],
            ['المتبقي معي نقدًا (إجمالي)', f(all['net']!)],
          ];
          return ListView(padding: const EdgeInsets.all(8), children: [
            Card(
              color: Colors.amber.shade50,
              child: ListTile(title: const Text('المتبقي معي نقدًا (إجمالي)'), trailing: Text(f(all['net']!), style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold))),
            ),
            periodChips(context, per, range, (p, r) => setState(() {
                  per = p;
                  range = r;
                })),
            Card(
              child: Column(children: [
                line('+ مبيعات نقدية', d['cs']!),
                line('+ تحصيلات من العملاء', d['col']!),
                line('+ مرتجع شراء مستلم', d['pr']!),
                line('− مرتجع بيع مسترد', d['cr']!),
                line('− مشتريات مدفوعة', d['pp']!),
                line('− مدفوعات للموردين', d['sp']!),
                line('− المصروفات', d['ex']!, c: Colors.red),
                line('− التحويلات للشركة', d['tr']!, c: Colors.orange.shade800),
                const Divider(),
                line('صافي الفترة', d['net']!, bold: true),
              ]),
            ),
            const Padding(padding: EdgeInsets.all(8), child: Text('تحويلات للشركة في الفترة', style: TextStyle(fontWeight: FontWeight.bold))),
            for (final m in tr)
              Card(
                child: ListTile(
                  leading: icon3d(Icons.send_rounded, const Color(0xFFD97706), size: 40),
                  title: Text(f(n(m['amount'])), style: const TextStyle(fontWeight: FontWeight.bold)),
                  subtitle: Text('${(m['date'] as String).substring(0, 10)}  ${m['note'] ?? ''}'),
                  onTap: () => editTransfer(m),
                ),
              ),
            if (tr.isEmpty) const Padding(padding: EdgeInsets.all(8), child: Text('لا توجد تحويلات في هذه الفترة')),
            const SizedBox(height: 70),
          ]);
        },
      ),
    );
  }
}

class InventoryPage extends StatefulWidget {
  const InventoryPage({super.key});
  @override
  State<InventoryPage> createState() => _IV();
}

class _IV extends State<InventoryPage> {
  final ctl = <int, TextEditingController>{};
  String s = '';
  DateTime dt = DateTime.now();

  Future<void> save() async {
    final all = await DB.q('SELECT id,name,qty FROM products');
    final d = await DB.db;
    var cnt = 0;
    await d.transaction((t) async {
      for (final m in all) {
        final c = ctl[m['id'] as int];
        if (c == null || c.text.trim().isEmpty) continue;
        final actual = pd(c.text), old = n(m['qty']);
        if (actual == old) continue;
        cnt++;
        await t.insert('stock_adj', {'product_id': m['id'], 'name': m['name'], 'old_qty': old, 'new_qty': actual, 'date': dt.toIso8601String()});
        await t.update('products', {'qty': actual}, where: 'id=?', whereArgs: [m['id']]);
      }
    });
    for (final c in ctl.values) {
      c.clear();
    }
    if (!mounted) return;
    setState(() {});
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(cnt == 0 ? 'لا توجد فروق' : 'تمت تسوية $cnt صنف')));
  }

  @override
  Widget build(BuildContext context) => DefaultTabController(
        length: 2,
        child: Scaffold(
          appBar: AppBar(title: const Text('جرد المخزون'), bottom: const TabBar(tabs: [Tab(text: 'جرد جديد'), Tab(text: 'سجل الفروق')])),
          body: TabBarView(children: [
            Column(children: [
              Padding(padding: const EdgeInsets.symmetric(horizontal: 16), child: dateTile(context, dt, (d) => setState(() => dt = d), label: 'تاريخ الجرد')),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 8),
                child: TextField(
                  onChanged: (v) => setState(() => s = v),
                  decoration: InputDecoration(prefixIcon: const Icon(Icons.search), hintText: 'بحث بالاسم', filled: true, fillColor: Colors.white, border: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: BorderSide.none)),
                ),
              ),
              Expanded(
                child: FutureBuilder<List<Map<String, Object?>>>(
                  future: DB.q('SELECT * FROM products WHERE name LIKE ? ORDER BY name', ['%$s%']),
                  builder: (c, snap) => ListView(padding: const EdgeInsets.all(8), children: [
                    for (final m in snap.data ?? <Map<String, Object?>>[])
                      Card(
                        child: ListTile(
                          title: Text(m['name'] as String),
                          subtitle: Text('بالنظام: ${f(n(m['qty']))} ${m['unit'] ?? ''}'),
                          trailing: SizedBox(
                            width: 96,
                            child: TextField(
                              controller: ctl.putIfAbsent(m['id'] as int, () => TextEditingController()),
                              keyboardType: const TextInputType.numberWithOptions(decimal: true),
                              textAlign: TextAlign.center,
                              decoration: const InputDecoration(hintText: 'الفعلي', isDense: true, border: OutlineInputBorder()),
                            ),
                          ),
                        ),
                      ),
                  ]),
                ),
              ),
              Padding(padding: const EdgeInsets.all(12), child: SizedBox(width: double.infinity, child: FilledButton.icon(onPressed: save, icon: const Icon(Icons.check_circle_rounded), label: const Padding(padding: EdgeInsets.all(8), child: Text('حفظ الجرد وتسوية الفروق'))))),
            ]),
            FutureBuilder<List<Map<String, Object?>>>(
              future: DB.q('SELECT * FROM stock_adj ORDER BY id DESC'),
              builder: (c, snap) {
                final r = snap.data ?? [];
                if (snap.hasData && r.isEmpty) return const Center(child: Text('لا توجد عمليات جرد سابقة'));
                return ListView(padding: const EdgeInsets.all(8), children: [
                  for (final m in r)
                    Card(
                      child: ListTile(
                        title: Text(m['name'] as String),
                        subtitle: Text('${(m['date'] as String).substring(0, 10)}  |  ${f(n(m['old_qty']))} ← ${f(n(m['new_qty']))}'),
                        trailing: Text(
                          '${n(m['new_qty']) - n(m['old_qty']) > 0 ? '+' : ''}${f(n(m['new_qty']) - n(m['old_qty']))}',
                          style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16, color: n(m['new_qty']) >= n(m['old_qty']) ? Colors.green : Colors.red),
                        ),
                      ),
                    ),
                ]);
              },
            ),
          ]),
        ),
      );
}
