import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'core.dart';
import 'products.dart';
import 'parties.dart';
import 'invoices.dart';

void main() => runApp(const App());

class App extends StatelessWidget {
  const App({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
        title: 'المبيعات والمخزون',
        debugShowCheckedModeBanner: false,
        locale: const Locale('ar'),
        supportedLocales: const [Locale('ar')],
        localizationsDelegates: const [
          GlobalMaterialLocalizations.delegate,
          GlobalWidgetsLocalizations.delegate,
          GlobalCupertinoLocalizations.delegate,
        ],
        theme: ThemeData(useMaterial3: true, colorScheme: ColorScheme.fromSeed(seedColor: Colors.teal)),
        home: const Home(),
      );
}

class Home extends StatefulWidget {
  const Home({super.key});
  @override
  State<Home> createState() => _HomeState();
}

class _HomeState extends State<Home> {
  Future<List<double>> stats() async {
    final s = await DB.q("SELECT COALESCE(SUM(total),0) v FROM invoices WHERE type='sale' AND date LIKE ?", ['${today()}%']);
    final c = await DB.q("SELECT COALESCE(SUM(b),0) v FROM (SELECT ${DB.bal} b FROM parties p WHERE p.type='customer') WHERE b>0");
    final u = await DB.q("SELECT COALESCE(SUM(b),0) v FROM (SELECT ${DB.bal} b FROM parties p WHERE p.type='supplier') WHERE b>0");
    final l = await DB.q('SELECT COUNT(*) v FROM products WHERE qty <= min_qty');
    return [n(s[0]['v']), n(c[0]['v']), n(u[0]['v']), n(l[0]['v'])];
  }

  void go(Widget w) => Navigator.push(context, MaterialPageRoute(builder: (_) => w)).then((_) => setState(() {}));

  Widget stat(String t, double v, IconData i) => Card(
        child: ListTile(leading: Icon(i), title: Text(t), trailing: Text(f(v), style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold))),
      );

  Widget tile(String t, IconData i, Widget page) => Card(
        child: InkWell(
          onTap: () => go(page),
          child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [Icon(i, size: 34), const SizedBox(height: 6), Text(t)]),
        ),
      );

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('المبيعات والمخزون')),
        body: ListView(padding: const EdgeInsets.all(12), children: [
          FutureBuilder<List<double>>(
            future: stats(),
            builder: (c, s) {
              final v = s.data ?? [0, 0, 0, 0];
              return Column(children: [
                stat('مبيعات اليوم', v[0], Icons.point_of_sale),
                stat('مستحق على العملاء', v[1], Icons.arrow_downward),
                stat('مستحق للموردين', v[2], Icons.arrow_upward),
                stat('أصناف قاربت على النفاد', v[3], Icons.warning_amber),
              ]);
            },
          ),
          const SizedBox(height: 8),
          GridView.count(
            crossAxisCount: 2, shrinkWrap: true, childAspectRatio: 1.5, physics: const NeverScrollableScrollPhysics(),
            children: [
              tile('بيع جديد', Icons.shopping_cart, const InvoicePage('sale')),
              tile('شراء جديد', Icons.local_shipping, const InvoicePage('purchase')),
              tile('الأصناف', Icons.inventory_2, const ProductsPage()),
              tile('الفواتير', Icons.receipt_long, const InvoicesPage()),
              tile('العملاء', Icons.people, const PartiesPage('customer')),
              tile('الموردين', Icons.store, const PartiesPage('supplier')),
            ],
          ),
        ]),
      );
}
