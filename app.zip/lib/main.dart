import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'core.dart';
import 'products.dart';
import 'parties.dart';
import 'invoices.dart';
import 'more.dart';
import 'backup.dart';

void main() => runApp(const App());

const kInk = Color(0xFF1E1B4B);
const kBg = Color(0xFFF5F6FB);
const kPrimary = Color(0xFF4F46E5);

class App extends StatelessWidget {
  const App({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
        title: 'MAN.rep',
        debugShowCheckedModeBanner: false,
        locale: const Locale('ar'),
        supportedLocales: const [Locale('ar')],
        localizationsDelegates: const [
          GlobalMaterialLocalizations.delegate,
          GlobalWidgetsLocalizations.delegate,
          GlobalCupertinoLocalizations.delegate,
        ],
        theme: ThemeData(
          useMaterial3: true,
          colorScheme: ColorScheme.fromSeed(seedColor: kPrimary),
          scaffoldBackgroundColor: kBg,
          appBarTheme: const AppBarTheme(
            centerTitle: true,
            backgroundColor: kBg,
            surfaceTintColor: Colors.transparent,
            elevation: 0,
            titleTextStyle: TextStyle(color: kInk, fontSize: 20, fontWeight: FontWeight.bold),
            iconTheme: IconThemeData(color: kInk),
          ),
          cardTheme: CardThemeData(
            elevation: 2,
            shadowColor: Colors.black12,
            surfaceTintColor: Colors.transparent,
            color: Colors.white,
            margin: const EdgeInsets.symmetric(vertical: 5, horizontal: 2),
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
          ),
          dialogTheme: DialogThemeData(backgroundColor: Colors.white, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(22))),
          filledButtonTheme: FilledButtonThemeData(style: FilledButton.styleFrom(shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)))),
          floatingActionButtonTheme: FloatingActionButtonThemeData(
            backgroundColor: kPrimary,
            foregroundColor: Colors.white,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
          ),
        ),
        home: const Home(),
      );
}

class Home extends StatefulWidget {
  const Home({super.key});
  @override
  State<Home> createState() => _HomeState();
}

class _HomeState extends State<Home> {
  Future<Map<String, double>> stats() async {
    Future<double> one(String sql, [List<Object?>? a]) async => n((await DB.q(sql, a))[0]['v']);
    return {
      'sales': await one("SELECT COALESCE(SUM(total),0) v FROM invoices WHERE type='sale' AND date LIKE ?", ['${today()}%']),
      'cust': await one("SELECT COALESCE(SUM(b),0) v FROM (SELECT ${DB.bal} b FROM parties p WHERE p.type='customer') WHERE b>0"),
      'supp': await one("SELECT COALESCE(SUM(b),0) v FROM (SELECT ${DB.bal} b FROM parties p WHERE p.type='supplier') WHERE b>0"),
      'low': await one('SELECT COUNT(*) v FROM products WHERE qty <= min_qty'),
      'exp': await one("SELECT COUNT(*) v FROM products WHERE expiry IS NOT NULL AND expiry<>'' AND qty>0 AND expiry<=?", [plusDays(30)]),
    };
  }

  void go(Widget w) => Navigator.push(context, MaterialPageRoute(builder: (_) => w)).then((_) => setState(() {}));

  Widget mini(String t, double v, Color c, IconData i) => Expanded(
        child: Card(
          child: Padding(
            padding: const EdgeInsets.all(12),
            child: Row(children: [
              icon3d(i, c, size: 38),
              const SizedBox(width: 10),
              Expanded(
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text(t, style: const TextStyle(fontSize: 11, color: Colors.black54)),
                  Text(f(v), style: const TextStyle(fontSize: 17, fontWeight: FontWeight.bold, color: kInk)),
                ]),
              ),
            ]),
          ),
        ),
      );

  Widget alert(String t, double v, IconData i, Color c, Widget page) => Card(
        color: v > 0 ? Color.lerp(Colors.white, c, .1) : Colors.white,
        child: ListTile(
          leading: icon3d(i, c, size: 40),
          title: Text(t, style: const TextStyle(fontWeight: FontWeight.w600)),
          trailing: Container(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
            decoration: BoxDecoration(color: c.withAlpha(30), borderRadius: BorderRadius.circular(20)),
            child: Text(f(v), style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16, color: c)),
          ),
          onTap: () => go(page),
        ),
      );

  Widget tile(String t, IconData i, Color c, Widget page) => InkWell(
        borderRadius: BorderRadius.circular(20),
        onTap: () => go(page),
        child: Container(
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(20),
            boxShadow: [BoxShadow(color: Colors.black.withAlpha(16), blurRadius: 14, offset: const Offset(0, 6))],
          ),
          child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
            icon3d(i, c, size: 50),
            const SizedBox(height: 10),
            Text(t, textAlign: TextAlign.center, style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w700, color: kInk)),
          ]),
        ),
      );

  @override
  Widget build(BuildContext context) => Scaffold(
        body: SafeArea(
          child: ListView(padding: const EdgeInsets.all(14), children: [
            FutureBuilder<Map<String, double>>(
              future: stats(),
              builder: (c, s) {
                final v = s.data ?? {};
                double g(String k) => v[k] ?? 0;
                return Column(children: [
                  ClipRRect(
                    borderRadius: BorderRadius.circular(26),
                    child: Container(
                      width: double.infinity,
                      padding: const EdgeInsets.all(22),
                      decoration: const BoxDecoration(gradient: LinearGradient(begin: Alignment.topRight, end: Alignment.bottomLeft, colors: [Color(0xFF4F46E5), Color(0xFF9333EA)])),
                      child: Stack(children: [
                        Positioned(left: -40, top: -50, child: CircleAvatar(radius: 80, backgroundColor: Colors.white.withAlpha(22))),
                        Positioned(right: -30, bottom: -60, child: CircleAvatar(radius: 70, backgroundColor: Colors.white.withAlpha(16))),
                        Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                          Row(children: [
                            icon3d(Icons.bolt_rounded, const Color(0xFFFBBF24), size: 40),
                            const SizedBox(width: 10),
                            const Text('MAN.rep', style: TextStyle(color: Colors.white, fontSize: 26, fontWeight: FontWeight.w800, letterSpacing: 1)),
                          ]),
                          const SizedBox(height: 18),
                          const Text('مبيعات اليوم', style: TextStyle(color: Colors.white70)),
                          Text(f(g('sales')), style: const TextStyle(color: Colors.white, fontSize: 36, fontWeight: FontWeight.w800)),
                        ]),
                      ]),
                    ),
                  ),
                  const SizedBox(height: 8),
                  Row(children: [
                    mini('مستحق على العملاء', g('cust'), const Color(0xFF10B981), Icons.south_west_rounded),
                    mini('مستحق للموردين', g('supp'), const Color(0xFFEF4444), Icons.north_east_rounded),
                  ]),
                  alert('أصناف قاربت على الانتهاء', g('exp'), Icons.event_busy_rounded, const Color(0xFFEF4444), const ExpiryPage()),
                  alert('أصناف قاربت على النفاد', g('low'), Icons.warning_amber_rounded, const Color(0xFFF59E0B), const ProductsPage(lowOnly: true)),
                ]);
              },
            ),
            const SizedBox(height: 10),
            GridView.count(
              crossAxisCount: 3,
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              mainAxisSpacing: 10,
              crossAxisSpacing: 10,
              childAspectRatio: 1.0,
              children: [
                tile('بيع', Icons.shopping_cart_rounded, const Color(0xFF10B981), const InvoicePage('sale')),
                tile('شراء', Icons.local_shipping_rounded, const Color(0xFF3B82F6), const InvoicePage('purchase')),
                tile('مرتجع بيع', Icons.keyboard_return_rounded, const Color(0xFFF97316), const InvoicePage('sale_return')),
                tile('مرتجع شراء', Icons.undo_rounded, const Color(0xFFEC4899), const InvoicePage('purchase_return')),
                tile('الأصناف', Icons.inventory_2_rounded, const Color(0xFF14B8A6), const ProductsPage()),
                tile('العملاء', Icons.people_alt_rounded, const Color(0xFF6366F1), const PartiesPage('customer')),
                tile('الموردين', Icons.storefront_rounded, const Color(0xFF8B5CF6), const PartiesPage('supplier')),
                tile('الفواتير', Icons.receipt_long_rounded, const Color(0xFF0EA5E9), const InvoicesPage()),
                tile('التحصيلات', Icons.payments_rounded, const Color(0xFF22C55E), const CollectionsPage()),
                tile('المصاريف', Icons.account_balance_wallet_rounded, const Color(0xFFEF4444), const ExpensesPage()),
                tile('التقارير', Icons.bar_chart_rounded, const Color(0xFF0F766E), const ReportsPage()),
                tile('نسخ احتياطي', Icons.cloud_upload_rounded, const Color(0xFF06B6D4), const BackupPage()),
              ],
            ),
          ]),
        ),
      );
}
