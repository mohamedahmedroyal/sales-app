import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'core.dart';
import 'products.dart';
import 'parties.dart';
import 'invoices.dart';
import 'more.dart';

void main() => runApp(const App());

class App extends StatelessWidget {
  const App({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
        title: 'royal rep',
        debugShowCheckedModeBanner: false,
        locale: const Locale('ar'),
        supportedLocales: const [Locale('ar')],
        localizationsDelegates: const [
          GlobalMaterialLocalizations.delegate,
          GlobalWidgetsLocalizations.delegate,
          GlobalCupertinoLocalizations.delegate,
        ],
        theme: ThemeData(
          useMaterial3: true,
          colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF3949AB)),
          scaffoldBackgroundColor: const Color(0xFFF4F5FA),
          cardTheme: CardThemeData(elevation: 0, color: Colors.white, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14))),
        ),
        home: const Home(),
      );
}

class Home extends StatefulWidget {
  const Home({super.key});
  @override
  State<Home> createState() => _HomeState();
}

class _HomeState extends State<Home> {
  Future<Map<String, double>> stats() async {
    Future<double> one(String sql, [List<Object?>? a]) async => n((await DB.q(sql, a))[0]['v']);
    return {
      'sales': await one("SELECT COALESCE(SUM(total),0) v FROM invoices WHERE type='sale' AND date LIKE ?", ['${today()}%']),
      'cust': await one("SELECT COALESCE(SUM(b),0) v FROM (SELECT ${DB.bal} b FROM parties p WHERE p.type='customer') WHERE b>0"),
      'supp': await one("SELECT COALESCE(SUM(b),0) v FROM (SELECT ${DB.bal} b FROM parties p WHERE p.type='supplier') WHERE b>0"),
      'low': await one('SELECT COUNT(*) v FROM products WHERE qty <= min_qty'),
      'exp': await one("SELECT COUNT(*) v FROM products WHERE expiry IS NOT NULL AND expiry<>'' AND qty>0 AND expiry<=?", [plusDays(30)]),
    };
  }

  void go(Widget w) => Navigator.push(context, MaterialPageRoute(builder: (_) => w)).then((_) => setState(() {}));

  Widget mini(String t, double v, Color c) => Expanded(
        child: Card(
          color: c.withAlpha(28),
          child: Padding(
            padding: const EdgeInsets.all(12),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(t, style: const TextStyle(fontSize: 12)),
              Text(f(v), style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: c)),
            ]),
          ),
        ),
      );

  Widget alert(String t, double v, IconData i, Color c, Widget page) => Card(
        color: v > 0 ? c.withAlpha(35) : Colors.white,
        child: ListTile(
          leading: Icon(i, color: c),
          title: Text(t),
          trailing: Text(f(v), style: TextStyle(fontWeight: FontWeight.bold, fontSize: 18, color: c)),
          onTap: () => go(page),
        ),
      );

  Widget tile(String t, IconData i, Color c, Widget page) => Card(
        child: InkWell(
          borderRadius: BorderRadius.circular(14),
          onTap: () => go(page),
          child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
            CircleAvatar(backgroundColor: c.withAlpha(35), child: Icon(i, color: c)),
            const SizedBox(height: 6),
            Text(t, textAlign: TextAlign.center, style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w600)),
          ]),
        ),
      );

  @override
  Widget build(BuildContext context) => Scaffold(
        body: SafeArea(
          child: ListView(padding: const EdgeInsets.all(12), children: [
            FutureBuilder<Map<String, double>>(
              future: stats(),
              builder: (c, s) {
                final v = s.data ?? {};
                double g(String k) => v[k] ?? 0;
                return Column(children: [
                  Container(
                    width: double.infinity,
                    padding: const EdgeInsets.all(20),
                    decoration: BoxDecoration(
                      gradient: const LinearGradient(colors: [Color(0xFF1A237E), Color(0xFF6A1B9A)]),
                      borderRadius: BorderRadius.circular(20),
                    ),
                    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      const Row(children: [
                        Icon(Icons.workspace_premium, color: Color(0xFFFFD54F), size: 30),
                        SizedBox(width: 8),
                        Text('royal rep', style: TextStyle(color: Colors.white, fontSize: 24, fontWeight: FontWeight.bold, letterSpacing: 1)),
                      ]),
                      const SizedBox(height: 16),
                      const Text('مبيعات اليوم', style: TextStyle(color: Colors.white70)),
                      Text(f(g('sales')), style: const TextStyle(color: Colors.white, fontSize: 34, fontWeight: FontWeight.bold)),
                    ]),
                  ),
                  const SizedBox(height: 8),
                  Row(children: [mini('مستحق على العملاء', g('cust'), Colors.green.shade700), mini('مستحق للموردين', g('supp'), Colors.red.shade700)]),
                  alert('أصناف قاربت على الانتهاء', g('exp'), Icons.event_busy, Colors.red.shade700, const ExpiryPage()),
                  alert('أصناف قاربت على النفاد', g('low'), Icons.warning_amber, Colors.orange.shade800, const ProductsPage(lowOnly: true)),
                ]);
              },
            ),
            const SizedBox(height: 8),
            GridView.count(
              crossAxisCount: 3,
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              mainAxisSpacing: 4,
              crossAxisSpacing: 4,
              childAspectRatio: 1.05,
              children: [
                tile('بيع', Icons.shopping_cart, Colors.green.shade700, const InvoicePage('sale')),
                tile('شراء', Icons.local_shipping, Colors.blue.shade700, const InvoicePage('purchase')),
                tile('مرتجع بيع', Icons.assignment_return, Colors.orange.shade800, const InvoicePage('sale_return')),
                tile('مرتجع شراء', Icons.undo, Colors.deepOrange, const InvoicePage('purchase_return')),
                tile('الأصناف', Icons.inventory_2, Colors.teal, const ProductsPage()),
                tile('العملاء', Icons.people, Colors.indigo, const PartiesPage('customer')),
                tile('الموردين', Icons.store, Colors.brown, const PartiesPage('supplier')),
                tile('الفواتير', Icons.receipt_long, Colors.purple, const InvoicesPage()),
                tile('التحصيلات', Icons.payments, Colors.green.shade800, const CollectionsPage()),
                tile('المصاريف', Icons.money_off, Colors.red.shade700, const ExpensesPage()),
                tile('التقارير', Icons.bar_chart, Colors.blueGrey, const ReportsPage()),
              ],
            ),
          ]),
        ),
      );
}
