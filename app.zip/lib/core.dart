import 'package:flutter/material.dart';
import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart' as p;

double n(Object? v) => v == null ? 0.0 : (v as num).toDouble();
double pd(String s) {
  const a = '٠١٢٣٤٥٦٧٨٩';
  var t = s.trim().replaceAll('٫', '.').replaceAll(',', '.');
  for (var i = 0; i < 10; i++) {
    t = t.replaceAll(a[i], '$i');
  }
  return double.tryParse(t) ?? 0.0;
}

String f(num v) => v == v.roundToDouble() ? v.toStringAsFixed(0) : v.toStringAsFixed(2);
String today() => DateTime.now().toIso8601String().substring(0, 10);
String plusDays(int d) => DateTime.now().add(Duration(days: d)).toIso8601String().substring(0, 10);
String monthStart() => '${today().substring(0, 8)}01';

const titles = {
  'sale': 'فاتورة بيع',
  'purchase': 'فاتورة شراء',
  'sale_return': 'مرتجع بيع',
  'purchase_return': 'مرتجع شراء',
};

Widget tf(TextEditingController c, String label, {bool isNum = false, void Function(String)? onChanged}) => Padding(
      padding: const EdgeInsets.symmetric(vertical: 6),
      child: TextField(
        controller: c,
        onChanged: onChanged,
        keyboardType: isNum ? const TextInputType.numberWithOptions(decimal: true) : TextInputType.text,
        decoration: InputDecoration(labelText: label, border: const OutlineInputBorder()),
      ),
    );

Future<bool> confirm(BuildContext c, String t) async =>
    (await showDialog<bool>(
      context: c,
      builder: (_) => AlertDialog(
        title: Text(t),
        actions: [
          TextButton(onPressed: () => Navigator.pop(c, false), child: const Text('لا')),
          FilledButton(onPressed: () => Navigator.pop(c, true), child: const Text('نعم')),
        ],
      ),
    )) ==
    true;

class DB {
  static Database? _d;
  static Future<Database> get db async => _d ??= await _open();

  static const _exp = 'CREATE TABLE expenses(id INTEGER PRIMARY KEY AUTOINCREMENT, category TEXT, amount REAL, date TEXT, note TEXT)';

  static Future<Database> _open() async {
    final path = p.join(await getDatabasesPath(), 'sales.db');
    return openDatabase(
      path,
      version: 2,
      onCreate: (d, v) async {
        await d.execute('CREATE TABLE products(id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT, barcode TEXT, unit TEXT, cost REAL, price REAL, qty REAL, min_qty REAL, expiry TEXT)');
        await d.execute('CREATE TABLE parties(id INTEGER PRIMARY KEY AUTOINCREMENT, type TEXT, name TEXT, phone TEXT, opening REAL, credit_limit REAL)');
        await d.execute('CREATE TABLE invoices(id INTEGER PRIMARY KEY AUTOINCREMENT, type TEXT, party_id INTEGER, date TEXT, total REAL, discount REAL, paid REAL)');
        await d.execute('CREATE TABLE items(id INTEGER PRIMARY KEY AUTOINCREMENT, invoice_id INTEGER, product_id INTEGER, name TEXT, qty REAL, price REAL, cost REAL DEFAULT 0)');
        await d.execute('CREATE TABLE payments(id INTEGER PRIMARY KEY AUTOINCREMENT, party_id INTEGER, amount REAL, date TEXT, note TEXT)');
        await d.execute(_exp);
      },
      onUpgrade: (d, o, v) async {
        if (o < 2) {
          await d.execute('ALTER TABLE products ADD COLUMN expiry TEXT');
          await d.execute('ALTER TABLE items ADD COLUMN cost REAL DEFAULT 0');
          await d.execute(_exp);
        }
      },
    );
  }

  static Future<List<Map<String, Object?>>> q(String sql, [List<Object?>? a]) async => (await db).rawQuery(sql, a);
  static Future<int> ins(String t, Map<String, Object?> v) async => (await db).insert(t, v);
  static Future<void> upd(String t, Map<String, Object?> v, int id) async {
    await (await db).update(t, v, where: 'id=?', whereArgs: [id]);
  }

  static Future<void> del(String t, int id) async {
    await (await db).delete(t, where: 'id=?', whereArgs: [id]);
  }

  // balance = opening + unpaid part of invoices (returns reduce it) - payments
  static const bal =
      "(p.opening + COALESCE((SELECT SUM(CASE WHEN type IN ('sale_return','purchase_return') THEN -(total-paid) ELSE total-paid END) FROM invoices WHERE party_id=p.id),0) - COALESCE((SELECT SUM(amount) FROM payments WHERE party_id=p.id),0))";

  static Future<void> saveInvoice(String type, int? partyId, List<Map<String, dynamic>> lines, double discount, double paid) async {
    final d = await db;
    await d.transaction((t) async {
      final sub = lines.fold<double>(0, (s, l) => s + n(l['qty']) * n(l['price']));
      final id = await t.insert('invoices', {
        'type': type, 'party_id': partyId, 'date': DateTime.now().toIso8601String(),
        'total': sub - discount, 'discount': discount, 'paid': paid,
      });
      for (final l in lines) {
        final pr = await t.rawQuery('SELECT cost FROM products WHERE id=?', [l['product_id']]);
        final cost = pr.isEmpty ? 0.0 : n(pr[0]['cost']);
        await t.insert('items', {'invoice_id': id, 'product_id': l['product_id'], 'name': l['name'], 'qty': l['qty'], 'price': l['price'], 'cost': cost});
        final q = n(l['qty']);
        final delta = (type == 'sale' || type == 'purchase_return') ? -q : q;
        await t.rawUpdate('UPDATE products SET qty = qty + ? WHERE id=?', [delta, l['product_id']]);
        if (type == 'purchase') {
          await t.rawUpdate('UPDATE products SET cost=? WHERE id=?', [l['price'], l['product_id']]);
        }
      }
    });
  }
}
