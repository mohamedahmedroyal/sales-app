import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'core.dart';
import 'invoices.dart';

Future<bool> askPayment(BuildContext context, Map<String, Object?> party) async {
  final isC = party['type'] == 'customer';
  final a = TextEditingController(), note = TextEditingController();
  final ok = await showDialog<bool>(
    context: context,
    builder: (_) => AlertDialog(
      title: Text('${isC ? 'تحصيل من' : 'سداد إلى'} ${party['name']}'),
      content: Column(mainAxisSize: MainAxisSize.min, children: [tf(a, 'المبلغ', isNum: true), tf(note, 'ملاحظة')]),
      actions: [
        TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('إلغاء')),
        FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('حفظ')),
      ],
    ),
  );
  if (ok != true || pd(a.text) <= 0) return false;
  await DB.ins('payments', {'party_id': party['id'], 'amount': pd(a.text), 'date': DateTime.now().toIso8601String(), 'note': note.text.trim()});
  return true;
}

Future<bool> editParty(BuildContext context, String type, [Map<String, Object?>? m]) async {
  final isC = type == 'customer';
  final name = TextEditingController(text: (m?['name'] ?? '').toString());
  final phone = TextEditingController(text: (m?['phone'] ?? '').toString());
  final open = TextEditingController(text: m == null ? '0' : f(n(m['opening'])));
  final lim = TextEditingController(text: m == null ? '0' : f(n(m['credit_limit'])));
  final ok = await showDialog<bool>(
    context: context,
    builder: (_) => AlertDialog(
      title: Text(m == null ? (isC ? 'عميل جديد' : 'مورد جديد') : 'تعديل الحساب'),
      content: SingleChildScrollView(
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          tf(name, 'الاسم'),
          tf(phone, 'التليفون'),
          tf(open, isC ? 'رصيد سابق عليه' : 'رصيد سابق له', isNum: true),
          if (isC) tf(lim, 'الحد الائتماني (0 = بدون حد)', isNum: true),
        ]),
      ),
      actions: [
        TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('إلغاء')),
        FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('حفظ')),
      ],
    ),
  );
  if (ok != true || name.text.trim().isEmpty) return false;
  final v = <String, Object?>{'type': type, 'name': name.text.trim(), 'phone': phone.text.trim(), 'opening': pd(open.text), 'credit_limit': pd(lim.text)};
  if (m == null) {
    await DB.ins('parties', v);
  } else {
    await DB.upd('parties', v, m['id'] as int);
  }
  return true;
}

class PartiesPage extends StatefulWidget {
  final String type; // customer | supplier
  final bool pick;
  const PartiesPage(this.type, {super.key, this.pick = false});
  @override
  State<PartiesPage> createState() => _PtS();
}

class _PtS extends State<PartiesPage> {
  String s = '';
  bool get isC => widget.type == 'customer';

  Future<void> add() async {
    if (await editParty(context, widget.type)) setState(() {});
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: Text(isC ? 'العملاء' : 'الموردين')),
        floatingActionButton: FloatingActionButton(onPressed: add, child: const Icon(Icons.person_add)),
        body: Column(children: [
          Padding(
            padding: const EdgeInsets.all(8),
            child: TextField(
              onChanged: (v) => setState(() => s = v),
              decoration: InputDecoration(
                prefixIcon: const Icon(Icons.search),
                hintText: 'بحث بالاسم',
                filled: true,
                fillColor: Colors.white,
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: BorderSide.none),
              ),
            ),
          ),
          Expanded(
            child: FutureBuilder<List<Map<String, Object?>>>(
              future: DB.q('SELECT p.*, ${DB.bal} AS bal FROM parties p WHERE p.type=? AND p.name LIKE ? ORDER BY p.name', [widget.type, '%$s%']),
              builder: (ctx, snap) {
                final r = snap.data ?? [];
                return ListView(padding: const EdgeInsets.symmetric(horizontal: 8), children: [
                  for (final m in r)
                    Card(
                      child: ListTile(
                        leading: icon3d(isC ? Icons.person_rounded : Icons.storefront_rounded, isC ? const Color(0xFF6366F1) : const Color(0xFF8B5CF6), size: 42),
                        title: Text(m['name'] as String),
                        subtitle: Text((m['phone'] ?? '').toString().isEmpty ? 'اضغط لعرض كشف الحساب' : '${m['phone']}  |  اضغط لعرض كشف الحساب'),
                        trailing: Text('${isC ? 'عليه' : 'له'}: ${f(n(m['bal']))}', style: TextStyle(fontWeight: FontWeight.bold, color: n(m['bal']) > 0 ? Colors.red : Colors.green)),
                        onTap: () {
                          if (widget.pick) {
                            Navigator.pop(ctx, m);
                          } else {
                            Navigator.push(ctx, MaterialPageRoute(builder: (_) => PartyPage(m))).then((_) => setState(() {}));
                          }
                        },
                      ),
                    ),
                ]);
              },
            ),
          ),
        ]),
      );
}

class PartyPage extends StatefulWidget {
  final Map<String, Object?> party;
  const PartyPage(this.party, {super.key});
  @override
  State<PartyPage> createState() => _PgS();
}

class _PgS extends State<PartyPage> {
  late Map<String, Object?> party = widget.party;
  String _txt = '';
  bool get isC => party['type'] == 'customer';

  Future<List<Map<String, dynamic>>> load() async {
    final id = party['id'] as int;
    final inv = await DB.q('SELECT id,type,date,total,paid FROM invoices WHERE party_id=?', [id]);
    final pay = await DB.q('SELECT id,date,amount,note FROM payments WHERE party_id=?', [id]);
    final e = <Map<String, dynamic>>[];
    for (final i in inv) {
      final t = i['type'] as String;
      final ret = t.endsWith('return');
      e.add({
        'date': i['date'],
        'inv': i['id'],
        'itype': t,
        'label': '${titles[t]} #${i['id']} (إجمالي ${f(n(i['total']))} / ${ret ? 'مسترد' : 'مدفوع'} ${f(n(i['paid']))})',
        'amt': (n(i['total']) - n(i['paid'])) * (ret ? -1 : 1),
      });
    }
    for (final y in pay) {
      e.add({'date': y['date'], 'label': '${isC ? 'تحصيل' : 'سداد'} ${y['note'] ?? ''}', 'amt': -n(y['amount']), 'pid': y['id'], 'pamt': n(y['amount']), 'pnote': y['note'] ?? ''});
    }
    e.sort((a, b) => (a['date'] as String).compareTo(b['date'] as String));
    return e;
  }

  Future<void> editMe() async {
    if (await editParty(context, party['type'] as String, party)) {
      final r = await DB.q('SELECT * FROM parties WHERE id=?', [party['id']]);
      setState(() => party = r.first);
    }
  }

  Future<void> delMe() async {
    final id = party['id'] as int;
    final c1 = await DB.q('SELECT COUNT(*) v FROM invoices WHERE party_id=?', [id]);
    final c2 = await DB.q('SELECT COUNT(*) v FROM payments WHERE party_id=?', [id]);
    if (!mounted) return;
    if (n(c1[0]['v']) + n(c2[0]['v']) > 0) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('لا يمكن حذف حساب عليه فواتير أو دفعات. عدّلها أو احذفها أولًا.')));
      return;
    }
    if (await confirm(context, 'حذف هذا الحساب؟')) {
      await DB.del('parties', id);
      if (mounted) Navigator.pop(context);
    }
  }

  Future<void> tapEntry(Map<String, dynamic> x) async {
    if (x['inv'] != null) {
      final r = await DB.q('SELECT * FROM invoices WHERE id=?', [x['inv']]);
      if (!mounted || r.isEmpty) return;
      await Navigator.push(context, MaterialPageRoute(builder: (_) => InvoicePage(x['itype'] as String, inv: r.first)));
      if (mounted) setState(() {});
      return;
    }
    final a = TextEditingController(text: f(x['pamt'] as double)), note = TextEditingController(text: x['pnote'].toString());
    final r = await showDialog<String>(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('تعديل الدفعة'),
        content: Column(mainAxisSize: MainAxisSize.min, children: [tf(a, 'المبلغ', isNum: true), tf(note, 'ملاحظة')]),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, 'del'), child: const Text('حذف', style: TextStyle(color: Colors.red))),
          TextButton(onPressed: () => Navigator.pop(context, 'no'), child: const Text('إلغاء')),
          FilledButton(onPressed: () => Navigator.pop(context, 'ok'), child: const Text('حفظ')),
        ],
      ),
    );
    if (r == 'ok' && pd(a.text) > 0) {
      await DB.upd('payments', {'amount': pd(a.text), 'note': note.text.trim()}, x['pid'] as int);
    } else if (r == 'del' && mounted && await confirm(context, 'حذف هذه الدفعة؟')) {
      await DB.del('payments', x['pid'] as int);
    }
    if (mounted) setState(() {});
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: Text('كشف حساب: ${party['name']}'), actions: [IconButton(icon: const Icon(Icons.edit_rounded), onPressed: editMe), IconButton(icon: const Icon(Icons.delete_outline_rounded), onPressed: delMe)]),
        body: FutureBuilder<List<Map<String, dynamic>>>(
          future: load(),
          builder: (c, s) {
            final e = s.data ?? [];
            var bal = n(party['opening']);
            final sb = StringBuffer('كشف حساب: ${party['name']}\nرصيد سابق: ${f(bal)}\n');
            final rows = <Widget>[Card(child: ListTile(title: const Text('رصيد سابق'), trailing: Text(f(bal))))];
            for (final x in e) {
              bal += x['amt'] as double;
              final d = (x['date'] as String).substring(0, 10);
              sb.writeln('$d | ${x['label']} | ${f(x['amt'] as double)} | الرصيد ${f(bal)}');
              rows.add(Card(child: ListTile(onTap: () => tapEntry(x), title: Text(x['label'] as String), subtitle: Text(d), trailing: Text(f(bal), style: const TextStyle(fontWeight: FontWeight.bold)))));
            }
            sb.writeln('الرصيد الحالي: ${f(bal)}');
            _txt = sb.toString();
            return Column(children: [
              Card(
                color: Colors.indigo.shade50,
                child: ListTile(
                  title: Text(isC ? 'المطلوب من العميل' : 'المطلوب للمورد'),
                  trailing: Text(f(bal), style: const TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
                ),
              ),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 8),
                child: Row(children: [
                  Expanded(
                    child: FilledButton.icon(
                      onPressed: () async {
                        if (await askPayment(context, party)) setState(() {});
                      },
                      icon: const Icon(Icons.payments),
                      label: Text(isC ? 'تسجيل تحصيل' : 'تسجيل سداد'),
                    ),
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    child: OutlinedButton.icon(
                      onPressed: () {
                        Clipboard.setData(ClipboardData(text: _txt));
                        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('تم نسخ الكشف، الصقه في واتساب')));
                      },
                      icon: const Icon(Icons.copy),
                      label: const Text('نسخ الكشف'),
                    ),
                  ),
                ]),
              ),
              Expanded(child: ListView(padding: const EdgeInsets.all(8), children: rows)),
            ]);
          },
        ),
      );
}
