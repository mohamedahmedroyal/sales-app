import 'package:flutter/material.dart';
import 'core.dart';

class PartiesPage extends StatefulWidget {
  final String type; // customer | supplier
  final bool pick;
  const PartiesPage(this.type, {super.key, this.pick = false});
  @override
  State<PartiesPage> createState() => _PtS();
}

class _PtS extends State<PartiesPage> {
  String s = '';
  bool get isC => widget.type == 'customer';

  Future<void> add() async {
    final name = TextEditingController(), phone = TextEditingController(), open = TextEditingController(text: '0'), lim = TextEditingController(text: '0');
    final ok = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        title: Text(isC ? 'عميل جديد' : 'مورد جديد'),
        content: SingleChildScrollView(
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            tf(name, 'الاسم'),
            tf(phone, 'التليفون'),
            tf(open, isC ? 'رصيد سابق عليه' : 'رصيد سابق له', isNum: true),
            if (isC) tf(lim, 'الحد الائتماني (0 = بدون حد)', isNum: true),
          ]),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('إلغاء')),
          FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('حفظ')),
        ],
      ),
    );
    if (ok != true || name.text.trim().isEmpty) return;
    await DB.ins('parties', {'type': widget.type, 'name': name.text.trim(), 'phone': phone.text.trim(), 'opening': pd(open.text), 'credit_limit': pd(lim.text)});
    setState(() {});
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: Text(isC ? 'العملاء' : 'الموردين')),
        floatingActionButton: FloatingActionButton(onPressed: add, child: const Icon(Icons.person_add)),
        body: Column(children: [
          Padding(
            padding: const EdgeInsets.all(8),
            child: TextField(
              onChanged: (v) => setState(() => s = v),
              decoration: const InputDecoration(prefixIcon: Icon(Icons.search), hintText: 'بحث بالاسم', border: OutlineInputBorder()),
            ),
          ),
          Expanded(
            child: FutureBuilder<List<Map<String, Object?>>>(
              future: DB.q('SELECT p.*, ${DB.bal} AS bal FROM parties p WHERE p.type=? AND p.name LIKE ? ORDER BY p.name', [widget.type, '%$s%']),
              builder: (ctx, snap) {
                final r = snap.data ?? [];
                return ListView(children: [
                  for (final m in r)
                    ListTile(
                      title: Text(m['name'] as String),
                      subtitle: Text((m['phone'] ?? '').toString()),
                      trailing: Text('${isC ? 'عليه' : 'له'}: ${f(n(m['bal']))}', style: TextStyle(color: n(m['bal']) > 0 ? Colors.red : Colors.green)),
                      onTap: () {
                        if (widget.pick) {
                          Navigator.pop(ctx, m);
                        } else {
                          Navigator.push(ctx, MaterialPageRoute(builder: (_) => PartyPage(m))).then((_) => setState(() {}));
                        }
                      },
                    ),
                ]);
              },
            ),
          ),
        ]),
      );
}

class PartyPage extends StatefulWidget {
  final Map<String, Object?> party;
  const PartyPage(this.party, {super.key});
  @override
  State<PartyPage> createState() => _PgS();
}

class _PgS extends State<PartyPage> {
  bool get isC => widget.party['type'] == 'customer';

  Future<List<Map<String, dynamic>>> load() async {
    final id = widget.party['id'] as int;
    final inv = await DB.q('SELECT id,type,date,total,paid FROM invoices WHERE party_id=?', [id]);
    final pay = await DB.q('SELECT id,date,amount,note FROM payments WHERE party_id=?', [id]);
    final e = <Map<String, dynamic>>[];
    for (final i in inv) {
      final kind = i['type'] == 'sale' ? 'بيع' : 'شراء';
      e.add({'date': i['date'], 'label': 'فاتورة $kind #${i['id']} (إجمالي ${f(n(i['total']))} / مدفوع ${f(n(i['paid']))})', 'amt': n(i['total']) - n(i['paid'])});
    }
    for (final y in pay) {
      e.add({'date': y['date'], 'label': '${isC ? 'تحصيل' : 'سداد'} ${y['note'] ?? ''}', 'amt': -n(y['amount'])});
    }
    e.sort((a, b) => (a['date'] as String).compareTo(b['date'] as String));
    return e;
  }

  Future<void> pay() async {
    final a = TextEditingController(), note = TextEditingController();
    final ok = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        title: Text(isC ? 'تحصيل من العميل' : 'سداد للمورد'),
        content: Column(mainAxisSize: MainAxisSize.min, children: [tf(a, 'المبلغ', isNum: true), tf(note, 'ملاحظة')]),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('إلغاء')),
          FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('حفظ')),
        ],
      ),
    );
    if (ok != true || pd(a.text) <= 0) return;
    await DB.ins('payments', {'party_id': widget.party['id'], 'amount': pd(a.text), 'date': DateTime.now().toIso8601String(), 'note': note.text.trim()});
    setState(() {});
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: Text(widget.party['name'] as String)),
        body: FutureBuilder<List<Map<String, dynamic>>>(
          future: load(),
          builder: (c, s) {
            final e = s.data ?? [];
            var bal = n(widget.party['opening']);
            final rows = <Widget>[ListTile(title: const Text('رصيد سابق'), trailing: Text(f(bal)))];
            for (final x in e) {
              bal += x['amt'] as double;
              rows.add(ListTile(title: Text(x['label'] as String), subtitle: Text((x['date'] as String).substring(0, 10)), trailing: Text(f(bal))));
            }
            return Column(children: [
              Card(
                child: ListTile(
                  title: Text(isC ? 'المطلوب من العميل' : 'المطلوب للمورد'),
                  trailing: Text(f(bal), style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
                ),
              ),
              FilledButton.icon(onPressed: pay, icon: const Icon(Icons.payments), label: Text(isC ? 'تسجيل تحصيل' : 'تسجيل سداد')),
              const Divider(),
              Expanded(child: ListView(children: rows)),
            ]);
          },
        ),
      );
}
