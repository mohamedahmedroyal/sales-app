import 'package:flutter/material.dart';
import 'core.dart';

class ProductsPage extends StatefulWidget {
  final bool pick;
  const ProductsPage({super.key, this.pick = false});
  @override
  State<ProductsPage> createState() => _PS();
}

class _PS extends State<ProductsPage> {
  String s = '';

  Future<void> edit(Map<String, Object?>? m) async {
    const keys = ['name', 'barcode', 'unit', 'cost', 'price', 'qty', 'min_qty'];
    const nums = ['cost', 'price', 'qty', 'min_qty'];
    final c = {
      for (final k in keys) k: TextEditingController(text: m == null ? '' : (nums.contains(k) ? f(n(m[k])) : (m[k] ?? '').toString()))
    };
    final ok = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        title: Text(m == null ? 'صنف جديد' : 'تعديل صنف'),
        content: SingleChildScrollView(
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            tf(c['name']!, 'الاسم'),
            tf(c['barcode']!, 'الباركود'),
            tf(c['unit']!, 'الوحدة (قطعة / كرتونة)'),
            tf(c['cost']!, 'سعر الشراء', isNum: true),
            tf(c['price']!, 'سعر البيع', isNum: true),
            tf(c['qty']!, 'الكمية الحالية', isNum: true),
            tf(c['min_qty']!, 'حد التنبيه', isNum: true),
          ]),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('إلغاء')),
          FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('حفظ')),
        ],
      ),
    );
    if (ok != true || c['name']!.text.trim().isEmpty) return;
    final v = <String, Object?>{
      'name': c['name']!.text.trim(),
      'barcode': c['barcode']!.text.trim(),
      'unit': c['unit']!.text.trim(),
      'cost': pd(c['cost']!.text),
      'price': pd(c['price']!.text),
      'qty': pd(c['qty']!.text),
      'min_qty': pd(c['min_qty']!.text),
    };
    if (m == null) {
      await DB.ins('products', v);
    } else {
      await DB.upd('products', v, m['id'] as int);
    }
    setState(() {});
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: Text(widget.pick ? 'اختر صنف' : 'الأصناف')),
        floatingActionButton: FloatingActionButton(onPressed: () => edit(null), child: const Icon(Icons.add)),
        body: Column(children: [
          Padding(
            padding: const EdgeInsets.all(8),
            child: TextField(
              onChanged: (v) => setState(() => s = v),
              decoration: const InputDecoration(prefixIcon: Icon(Icons.search), hintText: 'بحث بالاسم أو الباركود', border: OutlineInputBorder()),
            ),
          ),
          Expanded(
            child: FutureBuilder<List<Map<String, Object?>>>(
              future: DB.q('SELECT * FROM products WHERE name LIKE ? OR barcode LIKE ? ORDER BY name', ['%$s%', '%$s%']),
              builder: (ctx, snap) {
                final r = snap.data ?? [];
                return ListView(children: [
                  for (final m in r)
                    ListTile(
                      title: Text(m['name'] as String),
                      subtitle: Text('الكمية: ${f(n(m['qty']))} ${m['unit'] ?? ''}  |  البيع: ${f(n(m['price']))}'),
                      trailing: n(m['qty']) <= n(m['min_qty']) ? const Icon(Icons.warning, color: Colors.orange) : null,
                      onTap: () => widget.pick ? Navigator.pop(ctx, m) : edit(m),
                    ),
                ]);
              },
            ),
          ),
        ]),
      );
}
