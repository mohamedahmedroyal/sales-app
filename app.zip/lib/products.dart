import 'package:flutter/material.dart';
import 'core.dart';

class ProductsPage extends StatefulWidget {
  final bool pick, lowOnly;
  const ProductsPage({super.key, this.pick = false, this.lowOnly = false});
  @override
  State<ProductsPage> createState() => _PS();
}

class _PS extends State<ProductsPage> {
  String s = '';

  Future<void> edit(Map<String, Object?>? m) async {
    const keys = ['name', 'barcode', 'unit', 'cost', 'price', 'qty', 'min_qty'];
    const nums = ['cost', 'price', 'qty', 'min_qty'];
    final c = {
      for (final k in keys) k: TextEditingController(text: m == null ? '' : (nums.contains(k) ? f(n(m[k])) : (m[k] ?? '').toString()))
    };
    String? exp = m?['expiry'] as String?;
    if (exp != null && exp.isEmpty) exp = null;
    final ok = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        title: Text(m == null ? 'صنف جديد' : 'تعديل صنف'),
        content: SingleChildScrollView(
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            tf(c['name']!, 'الاسم'),
            tf(c['barcode']!, 'الباركود'),
            tf(c['unit']!, 'الوحدة (قطعة / كرتونة)'),
            tf(c['cost']!, 'سعر الشراء', isNum: true),
            tf(c['price']!, 'سعر البيع', isNum: true),
            tf(c['qty']!, 'الكمية الحالية', isNum: true),
            tf(c['min_qty']!, 'حد التنبيه', isNum: true),
            StatefulBuilder(
              builder: (ctx, set) => ListTile(
                contentPadding: EdgeInsets.zero,
                leading: const Icon(Icons.event),
                title: Text(exp == null ? 'تاريخ الصلاحية (اختياري)' : 'الصلاحية: $exp'),
                trailing: exp == null ? null : IconButton(icon: const Icon(Icons.clear), onPressed: () => set(() => exp = null)),
                onTap: () async {
                  final d = await showDatePicker(
                    context: ctx,
                    initialDate: DateTime.tryParse(exp ?? '') ?? DateTime.now(),
                    firstDate: DateTime(2000),
                    lastDate: DateTime(2100),
                  );
                  if (d != null) set(() => exp = d.toIso8601String().substring(0, 10));
                },
              ),
            ),
          ]),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('إلغاء')),
          FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('حفظ')),
        ],
      ),
    );
    if (ok != true || c['name']!.text.trim().isEmpty) return;
    final v = <String, Object?>{
      'name': c['name']!.text.trim(),
      'barcode': c['barcode']!.text.trim(),
      'unit': c['unit']!.text.trim(),
      'cost': pd(c['cost']!.text),
      'price': pd(c['price']!.text),
      'qty': pd(c['qty']!.text),
      'min_qty': pd(c['min_qty']!.text),
      'expiry': exp,
    };
    if (m == null) {
      await DB.ins('products', v);
    } else {
      await DB.upd('products', v, m['id'] as int);
    }
    setState(() {});
  }

  Widget row(BuildContext ctx, Map<String, Object?> m) {
    final e = (m['expiry'] ?? '').toString();
    final near = e.isNotEmpty && e.compareTo(plusDays(30)) <= 0;
    final low = n(m['qty']) <= n(m['min_qty']);
    return Card(
      child: ListTile(
        title: Text(m['name'] as String),
        subtitle: Text('الكمية: ${f(n(m['qty']))} ${m['unit'] ?? ''}  |  البيع: ${f(n(m['price']))}${e.isEmpty ? '' : '\nالصلاحية: $e'}'),
        isThreeLine: e.isNotEmpty,
        trailing: Row(mainAxisSize: MainAxisSize.min, children: [
          if (low) const Icon(Icons.warning, color: Colors.orange),
          if (near) const Icon(Icons.event_busy, color: Colors.red),
        ]),
        onTap: () => widget.pick ? Navigator.pop(ctx, m) : edit(m),
      ),
    );
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: Text(widget.pick ? 'اختر صنف' : (widget.lowOnly ? 'أصناف قاربت على النفاد' : 'الأصناف'))),
        floatingActionButton: FloatingActionButton(onPressed: () => edit(null), child: const Icon(Icons.add)),
        body: Column(children: [
          Padding(
            padding: const EdgeInsets.all(8),
            child: TextField(
              onChanged: (v) => setState(() => s = v),
              decoration: InputDecoration(
                prefixIcon: const Icon(Icons.search),
                hintText: 'بحث بالاسم أو الباركود',
                filled: true,
                fillColor: Colors.white,
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: BorderSide.none),
              ),
            ),
          ),
          Expanded(
            child: FutureBuilder<List<Map<String, Object?>>>(
              future: DB.q('SELECT * FROM products WHERE (name LIKE ? OR barcode LIKE ?) ${widget.lowOnly ? 'AND qty<=min_qty' : ''} ORDER BY name', ['%$s%', '%$s%']),
              builder: (ctx, snap) {
                final r = snap.data ?? [];
                return ListView(padding: const EdgeInsets.symmetric(horizontal: 8), children: [for (final m in r) row(ctx, m)]);
              },
            ),
          ),
        ]),
      );
}

class ExpiryPage extends StatefulWidget {
  const ExpiryPage({super.key});
  @override
  State<ExpiryPage> createState() => _ES();
}

class _ES extends State<ExpiryPage> {
  int days = 30;

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('أصناف قاربت على الانتهاء')),
        body: Column(children: [
          Padding(
            padding: const EdgeInsets.all(8),
            child: Wrap(spacing: 8, children: [
              for (final d in [7, 30, 60, 90])
                ChoiceChip(label: Text('خلال $d يوم'), selected: days == d, onSelected: (_) => setState(() => days = d)),
            ]),
          ),
          Expanded(
            child: FutureBuilder<List<Map<String, Object?>>>(
              future: DB.q("SELECT * FROM products WHERE expiry IS NOT NULL AND expiry<>'' AND qty>0 AND expiry<=? ORDER BY expiry", [plusDays(days)]),
              builder: (ctx, snap) {
                final r = snap.data ?? [];
                if (snap.hasData && r.isEmpty) return const Center(child: Text('لا توجد أصناف قاربت على الانتهاء ✅'));
                return ListView(padding: const EdgeInsets.symmetric(horizontal: 8), children: [
                  for (final m in r)
                    Builder(builder: (_) {
                      final left = DateTime.parse(m['expiry'] as String).difference(DateTime.now()).inDays;
                      final expired = left < 0;
                      return Card(
                        color: expired ? Colors.red.shade50 : Colors.orange.shade50,
                        child: ListTile(
                          title: Text(m['name'] as String),
                          subtitle: Text('الكمية: ${f(n(m['qty']))} ${m['unit'] ?? ''}\n${expired ? 'منتهي منذ ${-left} يوم' : 'باقي $left يوم'}'),
                          isThreeLine: true,
                          trailing: Text(m['expiry'] as String, style: TextStyle(fontWeight: FontWeight.bold, color: expired ? Colors.red : Colors.orange.shade900)),
                        ),
                      );
                    }),
                ]);
              },
            ),
          ),
        ]),
      );
}
