import 'dart:io';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:path_provider/path_provider.dart';
import 'package:share_plus/share_plus.dart';
import 'core.dart';

class BackupPage extends StatefulWidget {
  const BackupPage({super.key});
  @override
  State<BackupPage> createState() => _BS();
}

class _BS extends State<BackupPage> {
  bool busy = false;

  void msg(String t) => ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(t)));

  Future<void> backup() async {
    setState(() => busy = true);
    try {
      final data = await DB.exportJson();
      final dir = await getTemporaryDirectory();
      final file = File('${dir.path}/MANrep_backup_${today()}.json');
      await file.writeAsString(data);
      await Share.shareXFiles([XFile(file.path)], text: 'نسخة MAN.rep الاحتياطية');
    } catch (e) {
      if (mounted) msg('تعذر إنشاء النسخة: $e');
    }
    if (mounted) setState(() => busy = false);
  }

  Future<void> restore() async {
    final r = await FilePicker.platform.pickFiles();
    if (r == null || r.files.single.path == null || !mounted) return;
    if (!await confirm(context, 'سيتم استبدال كل البيانات الحالية بالنسخة المختارة. متأكد؟')) return;
    try {
      await DB.importJson(await File(r.files.single.path!).readAsString());
      if (mounted) msg('تمت الاستعادة بنجاح');
    } catch (e) {
      if (mounted) msg('تعذرت الاستعادة: $e');
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('النسخ الاحتياطي')),
        body: ListView(padding: const EdgeInsets.all(16), children: [
          const Card(
            child: Padding(
              padding: EdgeInsets.all(16),
              child: Text('احفظ نسخة من كل بياناتك (أصناف، عملاء، فواتير، تحصيلات، مصاريف) كملف، وابعتها لنفسك على واتساب أو Google Drive. اعمل نسخة بشكل دوري، وقبل أي تحديث للتطبيق.'),
            ),
          ),
          const SizedBox(height: 12),
          FilledButton.icon(
            onPressed: busy ? null : backup,
            icon: const Icon(Icons.share),
            label: const Padding(padding: EdgeInsets.all(10), child: Text('إنشاء نسخة احتياطية ومشاركتها')),
          ),
          const SizedBox(height: 12),
          OutlinedButton.icon(
            onPressed: restore,
            icon: const Icon(Icons.restore),
            label: const Padding(padding: EdgeInsets.all(10), child: Text('استعادة من ملف نسخة')),
          ),
        ]),
      );
}
