import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter_html_to_pdf_plus/flutter_html_to_pdf_plus.dart' as h;
import 'package:path_provider/path_provider.dart';
import 'package:share_plus/share_plus.dart';
import 'core.dart';

String esc(String s) => s.replaceAll('&', '&amp;').replaceAll('<', '&lt;').replaceAll('>', '&gt;');

String htmlDoc(String title, String sub, List<String> heads, List<List<String>> rows, {List<List<String>> totals = const []}) {
  final b = StringBuffer('<html dir="rtl" lang="ar"><head><meta charset="UTF-8"><style>'
      'body{font-family:sans-serif;direction:rtl;margin:14px;color:#1E1B4B}'
      '.top{background:#4F46E5;color:#fff;padding:12px 16px;border-radius:10px}.top h1{margin:0;font-size:22px}'
      'table{width:100%;border-collapse:collapse;margin-top:12px}'
      'th{background:#4F46E5;color:#fff}td,th{border:1px solid #cfd2e6;padding:6px 8px;font-size:12px;text-align:right}'
      'tr:nth-child(even) td{background:#f5f6fb}.tot td{font-weight:bold;background:#eef0ff}'
      '.f{color:#888;font-size:10px;margin-top:16px}</style></head><body>');
  b.write('<div class="top"><h1>MAN.rep</h1><div>${esc(title)}</div></div><p>${esc(sub)}</p><table><tr>');
  for (final x in heads) {
    b.write('<th>${esc(x)}</th>');
  }
  b.write('</tr>');
  for (final r in rows) {
    b.write('<tr>');
    for (final c in r) {
      b.write('<td>${esc(c)}</td>');
    }
    b.write('</tr>');
  }
  b.write('</table>');
  if (totals.isNotEmpty) {
    b.write('<table class="tot">');
    for (final t in totals) {
      b.write('<tr><td>${esc(t[0])}</td><td>${esc(t[1])}</td></tr>');
    }
    b.write('</table>');
  }
  b.write('<p class="f">MAN.rep - ${today()}</p></body></html>');
  return b.toString();
}

Future<void> sharePdf(BuildContext ctx, String name, String html) async {
  try {
    final dir = await getTemporaryDirectory();
    final File file = await h.FlutterHtmlToPdf.convertFromHtmlContent(
      content: html,
      configuration: h.PrintPdfConfiguration(targetDirectory: dir.path, targetName: name),
    );
    await Share.shareXFiles([XFile(file.path)]);
  } catch (e) {
    if (ctx.mounted) ScaffoldMessenger.of(ctx).showSnackBar(SnackBar(content: Text('تعذر إنشاء PDF: $e')));
  }
}

Future<void> stockPdf(BuildContext ctx) async {
  final r = await DB.q('SELECT * FROM products ORDER BY name');
  var tc = 0.0, tp = 0.0;
  final rows = <List<String>>[];
  for (final m in r) {
    final v = n(m['qty']) * n(m['cost']);
    tc += v;
    tp += n(m['qty']) * n(m['price']);
    rows.add([m['name'] as String, (m['unit'] ?? '').toString(), f(n(m['qty'])), f(n(m['cost'])), f(n(m['price'])), f(v), (m['expiry'] ?? '').toString()]);
  }
  if (!ctx.mounted) return;
  await sharePdf(ctx, 'stock_${today()}', htmlDoc('كشف المخزون', 'بتاريخ ${today()}', ['الصنف', 'الوحدة', 'الكمية', 'سعر الشراء', 'سعر البيع', 'قيمة الشراء', 'الصلاحية'], rows, totals: [['إجمالي قيمة المخزون بسعر الشراء', f(tc)], ['إجمالي قيمة المخزون بسعر البيع', f(tp)]]));
}

Future<void> partiesPdf(BuildContext ctx, String type) async {
  final isC = type == 'customer';
  final r = await DB.q("SELECT p.*, ${DB.bal} AS bal, ${DB.lastOp} AS last FROM parties p WHERE p.type=? ORDER BY last DESC, p.name", [type]);
  var tot = 0.0;
  final rows = <List<String>>[];
  for (final m in r) {
    tot += n(m['bal']);
    final l = (m['last'] ?? '').toString();
    rows.add([m['name'] as String, (m['phone'] ?? '').toString(), l.isEmpty ? '' : l.substring(0, 10), f(n(m['bal']))]);
  }
  if (!ctx.mounted) return;
  await sharePdf(ctx, '${type}_${today()}', htmlDoc(isC ? 'كشف أرصدة العملاء' : 'كشف أرصدة الموردين', 'بتاريخ ${today()}', ['الاسم', 'التليفون', 'آخر عملية', isC ? 'المطلوب منه' : 'المطلوب له'], rows, totals: [['الإجمالي', f(tot)]]));
}
