import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter_html_to_pdf_plus/flutter_html_to_pdf_plus.dart' as h;
import 'package:path_provider/path_provider.dart';
import 'package:printing/printing.dart';
import 'package:share_plus/share_plus.dart';
import 'core.dart';

String esc(String s) => s.replaceAll('&', '&amp;').replaceAll('<', '&lt;').replaceAll('>', '&gt;');

String htmlDoc(String title, String sub, List<String> heads, List<List<String>> rows, {List<List<String>> totals = const []}) {
  final b = StringBuffer('<html dir="rtl" lang="ar"><head><meta charset="UTF-8"><style>'
      'body{font-family:sans-serif;direction:rtl;margin:14px;color:#1E1B4B}'
      '.top{background:#4F46E5;color:#fff;padding:12px 16px;border-radius:10px}.top h1{margin:0;font-size:22px}'
      'table{width:100%;border-collapse:collapse;margin-top:12px}'
      'th{background:#4F46E5;color:#fff}td,th{border:1px solid #cfd2e6;padding:6px 8px;font-size:12px;text-align:right}'
      'tr:nth-child(even) td{background:#f5f6fb}.tot td{font-weight:bold;background:#eef0ff}'
      '.f{color:#888;font-size:10px;margin-top:16px}</style></head><body>');
  b.write('<div class="top"><h1>MAN.rep</h1><div>${esc(title)}</div></div><p>${esc(sub)}</p><table><tr>');
  for (final x in heads) {
    b.write('<th>${esc(x)}</th>');
  }
  b.write('</tr>');
  for (final r in rows) {
    b.write('<tr>');
    for (final c in r) {
      b.write('<td>${esc(c)}</td>');
    }
    b.write('</tr>');
  }
  b.write('</table>');
  if (totals.isNotEmpty) {
    b.write('<table class="tot">');
    for (final t in totals) {
      b.write('<tr><td>${esc(t[0])}</td><td>${esc(t[1])}</td></tr>');
    }
    b.write('</table>');
  }
  b.write('<p class="f">MAN.rep - ${today()}</p></body></html>');
  return b.toString();
}

Future<void> _pdfDo(BuildContext ctx, String name, String html, bool doPrint) async {
  try {
    final dir = await getTemporaryDirectory();
    final File file = await h.FlutterHtmlToPdf.convertFromHtmlContent(
      content: html,
      configuration: h.PrintPdfConfiguration(targetDirectory: dir.path, targetName: name),
    );
    if (doPrint) {
      await Printing.layoutPdf(onLayout: (_) async => await file.readAsBytes(), name: name);
    } else {
      await Share.shareXFiles([XFile(file.path)]);
    }
  } catch (e) {
    if (ctx.mounted) ScaffoldMessenger.of(ctx).showSnackBar(SnackBar(content: Text('تعذر إنشاء PDF: $e')));
  }
}

Future<void> sharePdf(BuildContext ctx, String name, String html) => _pdfDo(ctx, name, html, false);
Future<void> printPdf(BuildContext ctx, String name, String html) => _pdfDo(ctx, name, html, true);

Future<void> invoiceAction(BuildContext ctx, int invId, {bool doPrint = false}) async {
  final r = await DB.q('SELECT i.*, p.name pname FROM invoices i LEFT JOIN parties p ON p.id=i.party_id WHERE i.id=?', [invId]);
  if (r.isEmpty) return;
  final m = r.first;
  final it = await DB.q('SELECT * FROM items WHERE invoice_id=?', [invId]);
  final rows = <List<String>>[];
  var sub = 0.0;
  for (final x in it) {
    final t = n(x['qty']) * n(x['price']);
    sub += t;
    rows.add([x['name'] as String, f(n(x['qty'])), f(n(x['price'])), f(t)]);
  }
  final total = n(m['total']), paid = n(m['paid']);
  final ret = (m['type'] as String).endsWith('return');
  final note = (m['note'] ?? '').toString();
  final html = htmlDoc(
    '${titles[m['type']]} #${m['id']}',
    'التاريخ: ${(m['date'] as String).substring(0, 10)}  |  الاسم: ${m['pname'] ?? 'نقدي'}${note.isEmpty ? '' : '  |  ملاحظات: $note'}',
    ['الصنف', 'الكمية', 'السعر', 'الإجمالي'],
    rows,
    totals: [['المجموع', f(sub)], ['الخصم', f(n(m['discount']))], ['الإجمالي', f(total)], [ret ? 'المسترد نقدًا' : 'المدفوع', f(paid)], [ret ? 'يخصم من الحساب' : 'المتبقي', f(total - paid)]],
  );
  if (!ctx.mounted) return;
  await _pdfDo(ctx, 'invoice_${m['id']}', html, doPrint);
}

Future<void> stockPdf(BuildContext ctx) async {
  final r = await DB.q('SELECT * FROM products ORDER BY name');
  var tc = 0.0, tp = 0.0;
  final rows = <List<String>>[];
  for (final m in r) {
    final v = n(m['qty']) * n(m['cost']);
    tc += v;
    tp += n(m['qty']) * n(m['price']);
    rows.add([m['name'] as String, (m['unit'] ?? '').toString(), f(n(m['qty'])), f(n(m['cost'])), f(n(m['price'])), f(v), (m['expiry'] ?? '').toString()]);
  }
  if (!ctx.mounted) return;
  await sharePdf(ctx, 'stock_${today()}', htmlDoc('كشف المخزون', 'بتاريخ ${today()}', ['الصنف', 'الوحدة', 'الكمية', 'سعر الشراء', 'سعر البيع', 'قيمة الشراء', 'الصلاحية'], rows, totals: [['إجمالي قيمة المخزون بسعر الشراء', f(tc)], ['إجمالي قيمة المخزون بسعر البيع', f(tp)]]));
}

Future<void> partiesPdf(BuildContext ctx, String type) async {
  final isC = type == 'customer';
  final r = await DB.q("SELECT p.*, ${DB.bal} AS bal, ${DB.lastOp} AS last FROM parties p WHERE p.type=? ORDER BY last DESC, p.name", [type]);
  var tot = 0.0;
  final rows = <List<String>>[];
  for (final m in r) {
    tot += n(m['bal']);
    final l = (m['last'] ?? '').toString();
    rows.add([m['name'] as String, (m['phone'] ?? '').toString(), l.isEmpty ? '' : l.substring(0, 10), f(n(m['bal']))]);
  }
  if (!ctx.mounted) return;
  await sharePdf(ctx, '${type}_${today()}', htmlDoc(isC ? 'كشف أرصدة العملاء' : 'كشف أرصدة الموردين', 'بتاريخ ${today()}', ['الاسم', 'التليفون', 'آخر عملية', isC ? 'المطلوب منه' : 'المطلوب له'], rows, totals: [['الإجمالي', f(tot)]]));
}


Future<void> expensesPdf(BuildContext ctx, {bool doPrint = false}) async {
  final r = await DB.q('SELECT * FROM expenses ORDER BY date DESC, id DESC');
  var total = 0.0;
  final byCategory = <String, double>{};
  final rows = <List<String>>[];
  for (final m in r) {
    final amount = n(m['amount']);
    total += amount;
    final category = (m['category'] ?? 'أخرى').toString();
    byCategory[category] = (byCategory[category] ?? 0) + amount;
    final date = (m['date'] ?? '').toString();
    rows.add([
      date.length >= 10 ? date.substring(0, 10) : date,
      category,
      (m['note'] ?? '').toString(),
      f(amount),
    ]);
  }
  final categoryTotals = byCategory.entries
      .map((e) => <String>[e.key, f(e.value)])
      .toList();
  if (!ctx.mounted) return;
  await _pdfDo(
    ctx,
    'expenses_${today()}',
    htmlDoc(
      'كشف المصروفات',
      'جميع المصروفات المسجلة حتى ${today()}',
      ['التاريخ', 'البند', 'ملاحظات', 'المبلغ'],
      rows,
      totals: [
        ['إجمالي المصروفات', f(total)],
        ...categoryTotals,
      ],
    ),
    doPrint,
  );
}
