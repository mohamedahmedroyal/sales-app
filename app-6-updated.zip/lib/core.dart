import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart' as p;

double n(Object? v) => v == null ? 0.0 : (v as num).toDouble();
double pd(String s) {
  const a = '٠١٢٣٤٥٦٧٨٩';
  var t = s.trim().replaceAll('٫', '.').replaceAll(',', '.');
  for (var i = 0; i < 10; i++) {
    t = t.replaceAll(a[i], '$i');
  }
  return double.tryParse(t) ?? 0.0;
}

String f(num v) => v == v.roundToDouble() ? v.toStringAsFixed(0) : v.toStringAsFixed(2);
String today() => DateTime.now().toIso8601String().substring(0, 10);
String plusDays(int d) => DateTime.now().add(Duration(days: d)).toIso8601String().substring(0, 10);
String monthStart() => '${today().substring(0, 8)}01';

const titles = {
  'sale': 'فاتورة بيع',
  'purchase': 'فاتورة شراء',
  'sale_return': 'مرتجع بيع',
  'purchase_return': 'مرتجع شراء',
};

Widget tf(TextEditingController c, String label, {bool isNum = false, void Function(String)? onChanged}) => Padding(
      padding: const EdgeInsets.symmetric(vertical: 6),
      child: TextField(
        controller: c,
        onChanged: onChanged,
        keyboardType: isNum ? const TextInputType.numberWithOptions(decimal: true) : TextInputType.text,
        decoration: InputDecoration(labelText: label, border: const OutlineInputBorder()),
      ),
    );

Future<bool> confirm(BuildContext c, String t) async =>
    (await showDialog<bool>(
      context: c,
      builder: (_) => AlertDialog(
        title: Text(t),
        actions: [
          TextButton(onPressed: () => Navigator.pop(c, false), child: const Text('لا')),
          FilledButton(onPressed: () => Navigator.pop(c, true), child: const Text('نعم')),
        ],
      ),
    )) ==
    true;

class DB {
  static Database? _d;
  static Future<Database> get db async => _d ??= await _open();

  static const _tr = 'CREATE TABLE transfers(id INTEGER PRIMARY KEY AUTOINCREMENT, amount REAL, date TEXT, note TEXT)';
  static const _adj = 'CREATE TABLE stock_adj(id INTEGER PRIMARY KEY AUTOINCREMENT, product_id INTEGER, name TEXT, old_qty REAL, new_qty REAL, date TEXT)';
  static const _exp = 'CREATE TABLE expenses(id INTEGER PRIMARY KEY AUTOINCREMENT, category TEXT, amount REAL, date TEXT, note TEXT)';

  static Future<Database> _open() async {
    final path = p.join(await getDatabasesPath(), 'sales.db');
    return openDatabase(
      path,
      version: 4,
      onCreate: (d, v) async {
        await d.execute('CREATE TABLE products(id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT, barcode TEXT, unit TEXT, cost REAL, price REAL, qty REAL, min_qty REAL, expiry TEXT)');
        await d.execute('CREATE TABLE parties(id INTEGER PRIMARY KEY AUTOINCREMENT, type TEXT, name TEXT, phone TEXT, opening REAL, credit_limit REAL)');
        await d.execute('CREATE TABLE invoices(id INTEGER PRIMARY KEY AUTOINCREMENT, type TEXT, party_id INTEGER, date TEXT, total REAL, discount REAL, paid REAL, note TEXT)');
        await d.execute('CREATE TABLE items(id INTEGER PRIMARY KEY AUTOINCREMENT, invoice_id INTEGER, product_id INTEGER, name TEXT, qty REAL, price REAL, cost REAL DEFAULT 0)');
        await d.execute('CREATE TABLE payments(id INTEGER PRIMARY KEY AUTOINCREMENT, party_id INTEGER, amount REAL, date TEXT, note TEXT)');
        await d.execute(_exp);
        await d.execute(_tr);
        await d.execute(_adj);
      },
      onUpgrade: (d, o, v) async {
        if (o < 2) {
          await d.execute('ALTER TABLE products ADD COLUMN expiry TEXT');
          await d.execute('ALTER TABLE items ADD COLUMN cost REAL DEFAULT 0');
          await d.execute(_exp);
        }
        if (o < 3) {
          await d.execute(_tr);
          await d.execute(_adj);
        }
        if (o < 4) {
          await d.execute('ALTER TABLE invoices ADD COLUMN note TEXT');
        }
      },
    );
  }

  static Future<List<Map<String, Object?>>> q(String sql, [List<Object?>? a]) async => (await db).rawQuery(sql, a);
  static Future<int> ins(String t, Map<String, Object?> v) async => (await db).insert(t, v);
  static Future<void> upd(String t, Map<String, Object?> v, int id) async {
    await (await db).update(t, v, where: 'id=?', whereArgs: [id]);
  }

  static Future<void> del(String t, int id) async {
    await (await db).delete(t, where: 'id=?', whereArgs: [id]);
  }

  // balance = opening + unpaid part of invoices (returns reduce it) - payments
  static const lastOp = "MAX(COALESCE((SELECT MAX(date) FROM invoices WHERE party_id=p.id),''), COALESCE((SELECT MAX(date) FROM payments WHERE party_id=p.id),''))";

  static const bal =
      "(p.opening + COALESCE((SELECT SUM(CASE WHEN type IN ('sale_return','purchase_return') THEN -(total-paid) ELSE total-paid END) FROM invoices WHERE party_id=p.id),0) - COALESCE((SELECT SUM(amount) FROM payments WHERE party_id=p.id),0))";


  static const _tables = ['products', 'parties', 'invoices', 'items', 'payments', 'expenses', 'transfers', 'stock_adj'];

  static Future<String> exportJson() async {
    final d = await db;
    final m = <String, dynamic>{'app': 'royal_rep', 'version': 2, 'date': DateTime.now().toIso8601String()};
    for (final t in _tables) {
      m[t] = await d.query(t);
    }
    return jsonEncode(m);
  }

  static Future<void> importJson(String s) async {
    final m = jsonDecode(s) as Map<String, dynamic>;
    if (m['app'] != 'royal_rep') throw 'الملف ليس نسخة MAN.rep';
    final d = await db;
    await d.transaction((t) async {
      for (final k in _tables) {
        await t.delete(k);
      }
      for (final k in _tables) {
        for (final r in (m[k] as List? ?? [])) {
          await t.insert(k, Map<String, Object?>.from(r as Map));
        }
      }
    });
  }

  static Future<void> _reverse(Transaction t, String type, int invId) async {
    final old = await t.query('items', where: 'invoice_id=?', whereArgs: [invId]);
    for (final o in old) {
      final q = n(o['qty']);
      final delta = (type == 'sale' || type == 'purchase_return') ? q : -q;
      await t.rawUpdate('UPDATE products SET qty = qty + ? WHERE id=?', [delta, o['product_id']]);
    }
    await t.delete('items', where: 'invoice_id=?', whereArgs: [invId]);
  }

  static Future<void> deleteInvoice(int id, String type) async {
    final d = await db;
    await d.transaction((t) async {
      await _reverse(t, type, id);
      await t.delete('invoices', where: 'id=?', whereArgs: [id]);
    });
  }

  static Future<int> saveInvoice(String type, int? partyId, List<Map<String, dynamic>> lines, double discount, double paid, {int? editId, String? date, String? note}) async {
    final d = await db;
    return d.transaction<int>((t) async {
      final sub = lines.fold<double>(0, (s, l) => s + n(l['qty']) * n(l['price']));
      int id;
      if (editId != null) {
        await _reverse(t, type, editId);
        await t.update('invoices', {'party_id': partyId, 'total': sub - discount, 'discount': discount, 'paid': paid, 'note': note, if (date != null) 'date': date}, where: 'id=?', whereArgs: [editId]);
        id = editId;
      } else {
        id = await t.insert('invoices', {
          'type': type, 'party_id': partyId, 'date': date ?? DateTime.now().toIso8601String(),
          'total': sub - discount, 'discount': discount, 'paid': paid, 'note': note,
        });
      }
      for (final l in lines) {
        final pr = await t.rawQuery('SELECT cost FROM products WHERE id=?', [l['product_id']]);
        final cost = pr.isEmpty ? 0.0 : n(pr[0]['cost']);
        await t.insert('items', {'invoice_id': id, 'product_id': l['product_id'], 'name': l['name'], 'qty': l['qty'], 'price': l['price'], 'cost': cost});
        final q = n(l['qty']);
        final delta = (type == 'sale' || type == 'purchase_return') ? -q : q;
        await t.rawUpdate('UPDATE products SET qty = qty + ? WHERE id=?', [delta, l['product_id']]);
        if (type == 'purchase') {
          await t.rawUpdate('UPDATE products SET cost=? WHERE id=?', [l['price'], l['product_id']]);
        }
      }
      return id;
    });
  }
}

Widget icon3d(IconData i, Color c, {double size = 46}) => Container(
      width: size,
      height: size,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(size * .32),
        gradient: LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight, colors: [Color.lerp(c, Colors.white, .35)!, c, Color.lerp(c, Colors.black, .28)!]),
        boxShadow: [
          BoxShadow(color: c.withAlpha(120), blurRadius: 10, offset: const Offset(0, 6)),
          BoxShadow(color: Colors.white.withAlpha(160), blurRadius: 2, offset: const Offset(-1, -1)),
        ],
      ),
      child: Icon(i, color: Colors.white, size: size * .54, shadows: const [Shadow(color: Colors.black38, blurRadius: 4, offset: Offset(0, 2))]),
    );

String dstr(DateTime d) => d.toIso8601String().substring(0, 10);

Widget dateTile(BuildContext c, DateTime d, void Function(DateTime) onPick, {String label = 'التاريخ'}) => ListTile(
      contentPadding: EdgeInsets.zero,
      leading: const Icon(Icons.event_rounded),
      title: Text('$label: ${dstr(d)}'),
      trailing: const Icon(Icons.edit_calendar_rounded),
      onTap: () async {
        final p = await showDatePicker(context: c, initialDate: d, firstDate: DateTime(2000), lastDate: DateTime(2100));
        if (p != null) onPick(DateTime(p.year, p.month, p.day, d.hour, d.minute));
      },
    );

List<String> bounds(int per, DateTimeRange? r) {
  if (per == 0) return [today(), plusDays(1)];
  if (per == 1) return [monthStart(), '9999'];
  if (per == 3 && r != null) return [dstr(r.start), dstr(r.end.add(const Duration(days: 1)))];
  return ['', '9999'];
}

String periodLabel(int per, DateTimeRange? r) =>
    per == 0 ? 'اليوم ${today()}' : (per == 1 ? 'من ${monthStart()}' : (per == 3 && r != null ? 'من ${dstr(r.start)} إلى ${dstr(r.end)}' : 'كل الفترات'));

Widget periodChips(BuildContext c, int per, DateTimeRange? r, void Function(int, DateTimeRange?) on) => Wrap(spacing: 8, children: [
      for (final e in [(0, 'اليوم'), (1, 'هذا الشهر'), (2, 'الكل')]) ChoiceChip(label: Text(e.$2), selected: per == e.$1, onSelected: (_) => on(e.$1, r)),
      ChoiceChip(
        label: Text(per == 3 && r != null ? '${dstr(r.start)} → ${dstr(r.end)}' : 'فترة محددة'),
        selected: per == 3,
        onSelected: (_) async {
          final p = await showDateRangePicker(context: c, firstDate: DateTime(2000), lastDate: DateTime(2100), initialDateRange: r);
          if (p != null) on(3, p);
        },
      ),
    ]);
